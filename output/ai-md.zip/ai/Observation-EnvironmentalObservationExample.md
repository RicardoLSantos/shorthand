# Environmental Observation Example - iOS Lifestyle Medicine Implementation Guide v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Environmental Observation Example**

iOS Lifestyle Medicine Implementation Guide - Compilação de desenvolvimento local (v0.1.0) construída pelas ferramentas de compilação FHIR (HL7® FHIR® Standard). Veja o [Diretório de versões publicadas](https://2rdoc.pt/ig/ios-lifestyle-medicine/history.html)

*  [Narrative Content](#) 
*  [XML](Observation-EnvironmentalObservationExample.xml.md) 
*  [JSON](Observation-EnvironmentalObservationExample.json.md) 
*  [TTL](Observation-EnvironmentalObservationExample.ttl.md) 

## Example Observation: Environmental Observation Example

Perfil: [Environmental Observation Profile](StructureDefinition-environmental-observation.md)

**status**: Final

**category**: Survey

**code**: Body position finding

**subject**: [John Doe Male, DoB: 1970-01-01 ( urn:oid:2.16.858.1.1.1#12345)](Patient-PatientExample.md)

**effective**: 2024-03-19 14:00:00+0000

**performer**: [Practitioner Jane Smith](Practitioner-PractitionerExample.md)

**value**: Sitting position

**note**: 

> 

Environmental context observation


**device**: [Device: identifier = urn:oid:2.16.840.1.113883.3.4.5.4#iPhone-ENV-001; status = active; manufacturer = Apple Inc.; modelNumber = iPhone 15 Pro; type = Environmental sensor device](Device-EnvironmentalDeviceExample.md)

 IG © 2024+ [Ricardo Lourenço dos Santos](https://linktr.ee/ricardolsantos). Package iOS-Lifestyle-Medicine#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-03 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

