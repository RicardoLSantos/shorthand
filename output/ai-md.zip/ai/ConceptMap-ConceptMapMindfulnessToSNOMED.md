# Mindfulness Observations to SNOMED CT Mapping - iOS Lifestyle Medicine Implementation Guide v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Mindfulness Observations to SNOMED CT Mapping**

iOS Lifestyle Medicine Implementation Guide - Compilação de desenvolvimento local (v0.1.0) construída pelas ferramentas de compilação FHIR (HL7® FHIR® Standard). Veja o [Diretório de versões publicadas](https://2rdoc.pt/ig/ios-lifestyle-medicine/history.html)

*  [Narrative Content](#) 
*  [XML](ConceptMap-ConceptMapMindfulnessToSNOMED.xml.md) 
*  [JSON](ConceptMap-ConceptMapMindfulnessToSNOMED.json.md) 
*  [TTL](ConceptMap-ConceptMapMindfulnessToSNOMED.ttl.md) 

## ConceptMap: Mindfulness Observations to SNOMED CT Mapping 

| | |
| :--- | :--- |
| *Official URL*:https://2rdoc.pt/ig/ios-lifestyle-medicine/ConceptMap/ConceptMapMindfulnessToSNOMED | *Version*:0.1.0 |
| Active as of 2025-11-22 | *Computable Name*:ConceptMapMindfulnessToSNOMED |

 
Operational ConceptMap for mindfulness observation terminology translation. Enables runtime $translate operations for semantic interoperability between mindfulness/meditation tracking applications and SNOMED CT standard terminology. 

 
Provides semantic mappings from custom mindfulness observation codes to standard SNOMED CT codes. Mindfulness and meditation tracking is increasingly common in consumer health apps but lacks standardized clinical terminology. 

Mapeamento de (não especificado) para (não especificado)

**Grupo 1**Mapeamento de [Lifestyle Medicine Observation Codes](CodeSystem-lifestyle-observation-cs.md) to [SNOMED CT (all versions)](http://hl7.org/fhir/R4/codesystem-snomedct.html)

* **Código fonte**: mindfulness-session (Mindfulness practice session)
  * **Relacionamento**: [maps to wider concept](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#wider)
  * **Código de destino**: 228432001 (Meditation (regime/therapy))
  * **Comentário**: Mindfulness session maps to broader SNOMED 'Meditation' concept. Mindfulness is a specific type of meditation practice. Code 228432001 should be verified via SNOMED CT Browser.
* **Código fonte**: relaxation-response (Relaxation response observation)
  * **Relacionamento**: [is related to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#relatedto)
  * **Código de destino**: 398144009 (Relaxation (observable entity))
  * **Comentário**: Relaxation response observation relates to SNOMED 'Relaxation' concept but measures subjective experience vs objective state. Code 398144009 should be verified.
* **Código fonte**: mindfulness-type (Type of mindfulness practice)
  * **Relacionamento**: (not mapped)
  * **Código de destino**: No specific SNOMED CT code for categorizing mindfulness practice types (breathing, body scan, loving-kindness, etc.) as of November 2025. SNOMED has general meditation/relaxation concepts but lacks granularity for mindfulness subtypes.

 IG © 2024+ [Ricardo Lourenço dos Santos](https://linktr.ee/ricardolsantos). Package iOS-Lifestyle-Medicine#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-11-27 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

