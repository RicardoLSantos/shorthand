# Mindfulness Diagnostic Mappings - iOS Lifestyle Medicine Implementation Guide v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Mindfulness Diagnostic Mappings**

iOS Lifestyle Medicine Implementation Guide - Compilação de desenvolvimento local (v0.1.0) construída pelas ferramentas de compilação FHIR (HL7® FHIR® Standard). Veja o [Diretório de versões publicadas](https://2rdoc.pt/ig/ios-lifestyle-medicine/history.html)

*  [Narrative Content](#) 
*  [XML](ConceptMap-MindfulnessDiagnosticMap.xml.md) 
*  [JSON](ConceptMap-MindfulnessDiagnosticMap.json.md) 
*  [TTL](ConceptMap-MindfulnessDiagnosticMap.ttl.md) 

## ConceptMap: Mindfulness Diagnostic Mappings 

| | |
| :--- | :--- |
| *Official URL*:https://2rdoc.pt/ig/ios-lifestyle-medicine/ConceptMap/MindfulnessDiagnosticMap | *Version*:0.1.0 |
| Draft as of 2025-10-03 | *Computable Name*:MindfulnessDiagnosticMap |

 
Mapping of mindfulness outcomes to diagnostic codes 

 
Map mindfulness outcomes to standard diagnostic codes 

Mapeamento de [Mindfulness Outcomes Value Set](ValueSet-mindfulness-outcome-vs.md) para [Mindfulness SNOMED CT Value Set](ValueSet-mindfulness-snomed-vs.md)

**Grupo 1**Mapeamento de [Mindfulness Outcomes](CodeSystem-mindfulness-outcome-cs.md) to [SNOMED CT (all versions)](http://hl7.org/fhir/R4/codesystem-snomedct.html)

* **Código fonte**: stressReduction
  * **Relacionamento**: [narrower](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#narrower)
  * **Código de destino**: 73595000 (Stress)
  * **Comentário**: Indicates reduction in stress levels
* **Código fonte**: improvedSleep
  * **Relacionamento**: [narrower](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#narrower)
  * **Código de destino**: 248234008 (Sleep pattern)
  * **Comentário**: Indicates improvement in activity quality
* **Código fonte**: emotionalBalance
  * **Relacionamento**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Código de destino**: 285854004 (Emotional state)
  * **Comentário**: Maps to emotional state finding
* **Código fonte**: increasedAwareness
  * **Relacionamento**: [is related to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#relatedto)
  * **Código de destino**: 736253002 (Mental state, behavior and/or psychosocial functioning)
  * **Comentário**: General improvement in mental state

 IG © 2024+ [Ricardo Lourenço dos Santos](https://linktr.ee/ricardolsantos). Package iOS-Lifestyle-Medicine#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-03 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

