# Nutrition Measurements to SNOMED CT Mapping - iOS Lifestyle Medicine Implementation Guide v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Nutrition Measurements to SNOMED CT Mapping**

iOS Lifestyle Medicine Implementation Guide - Compilação de desenvolvimento local (v0.1.0) construída pelas ferramentas de compilação FHIR (HL7® FHIR® Standard). Veja o [Diretório de versões publicadas](https://2rdoc.pt/ig/ios-lifestyle-medicine/history.html)

*  [Narrative Content](#) 
*  [XML](ConceptMap-ConceptMapNutritionToSNOMED.xml.md) 
*  [JSON](ConceptMap-ConceptMapNutritionToSNOMED.json.md) 
*  [TTL](ConceptMap-ConceptMapNutritionToSNOMED.ttl.md) 

## ConceptMap: Nutrition Measurements to SNOMED CT Mapping 

| | |
| :--- | :--- |
| *Official URL*:https://2rdoc.pt/ig/ios-lifestyle-medicine/ConceptMap/ConceptMapNutritionToSNOMED | *Version*:0.1.0 |
| Active as of 2025-11-22 | *Computable Name*:ConceptMapNutritionToSNOMED |

 
Operational ConceptMap for nutrition measurement terminology translation. Enables runtime $translate operations for semantic interoperability between consumer nutrition tracking applications and SNOMED CT standard terminology. 

 
Provides semantic mappings from custom nutrition measurement codes to standard SNOMED CT codes. Consumer nutrition tracking uses proprietary measurements not fully covered by SNOMED CT. This ConceptMap enables clinical decision support systems to interpret consumer nutrition data using standardized terminology where available. 

Mapeamento de (não especificado) para (não especificado)

**Grupo 1**Mapeamento de [Lifestyle Medicine Observation Codes](CodeSystem-lifestyle-observation-cs.md) to [SNOMED CT (all versions)](http://hl7.org/fhir/R4/codesystem-snomedct.html)

* **Código fonte**: water-intake (Water intake volume)
  * **Relacionamento**: [narrower](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#narrower)
  * **Código de destino**: 226364002 (Fluid intake (observable entity))
  * **Comentário**: Water intake maps to broader SNOMED concept 'Fluid intake'. Target includes all fluids (water, juice, etc.), source is specific to water only. Code 226364002 should be verified via SNOMED CT Browser.
* **Código fonte**: caloric-intake (Total caloric intake)
  * **Relacionamento**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Código de destino**: 226355004 (Dietary energy intake (observable entity))
  * **Comentário**: Caloric intake maps to SNOMED 'Dietary energy intake'. Code 226355004 should be verified via SNOMED CT Browser before clinical use.
* **Código fonte**: macronutrients-panel (Macronutrients intake panel)
  * **Relacionamento**: (not mapped)
  * **Código de destino**: No exact SNOMED CT code for macronutrients panel as of November 2025. SNOMED has individual codes for protein, carbohydrate, and fat intake but not a panel concept. Individual component mappings below.
* **Código fonte**: protein-intake
  * **Relacionamento**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Código de destino**: 226357007 (Dietary protein intake (observable entity))
  * **Comentário**: Protein intake maps to SNOMED 'Dietary protein intake'. Code 226357007 should be verified via SNOMED CT Browser.
* **Código fonte**: fat-intake
  * **Relacionamento**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Código de destino**: 226358002 (Dietary fat intake (observable entity))
  * **Comentário**: Fat intake maps to SNOMED 'Dietary fat intake'. Code 226358002 should be verified via SNOMED CT Browser.
* **Código fonte**: carbohydrate-intake
  * **Relacionamento**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Código de destino**: 226359005 (Dietary carbohydrate intake (observable entity))
  * **Comentário**: Carbohydrate intake maps to SNOMED 'Dietary carbohydrate intake'. Code 226359005 should be verified via SNOMED CT Browser.

 IG © 2024+ [Ricardo Lourenço dos Santos](https://linktr.ee/ricardolsantos). Package iOS-Lifestyle-Medicine#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-11-27 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

