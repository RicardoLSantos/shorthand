# Example of Mindfulness Session Observation - iOS Lifestyle Medicine Implementation Guide v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Example of Mindfulness Session Observation**

iOS Lifestyle Medicine Implementation Guide - Compilação de desenvolvimento local (v0.1.0) construída pelas ferramentas de compilação FHIR (HL7® FHIR® Standard). Veja o [Diretório de versões publicadas](https://2rdoc.pt/ig/ios-lifestyle-medicine/history.html)

*  [Narrative Content](#) 
*  [XML](Observation-MindfulnessObservationExample.xml.md) 
*  [JSON](Observation-MindfulnessObservationExample.json.md) 
*  [TTL](Observation-MindfulnessObservationExample.ttl.md) 

## Example Observation: Example of Mindfulness Session Observation

Perfil: [Mindfulness Session Observation](StructureDefinition-mindfulness-observation.md)

**status**: Final

**code**: Mindfulness practice session

**subject**: [John Doe Male, DoB: 1970-01-01 ( urn:oid:2.16.858.1.1.1#12345)](Patient-PatientExample.md)

**effective**: 2024-03-19 09:30:00+0000

**performer**: [Practitioner Jane Smith](Practitioner-PractitionerExample.md)

> **component****code**:Process duration**value**: 20 min(Detalhes: UCUM códigomin = 'min')

> **component****code**:Health-related behavior finding**value**: 4

> **component****code**:Mood finding**value**:Calm

> **component****code**:Relaxation response observation**value**: Deep breathing exercises helped reduce tension

> **component****code**:Type of mindfulness practice**value**:Meditation

 IG © 2024+ [Ricardo Lourenço dos Santos](https://linktr.ee/ricardolsantos). Package iOS-Lifestyle-Medicine#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-03 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

