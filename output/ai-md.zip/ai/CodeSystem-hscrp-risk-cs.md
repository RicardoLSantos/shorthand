# hs-CRP Cardiovascular Risk CodeSystem - iOS Lifestyle Medicine Implementation Guide v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **hs-CRP Cardiovascular Risk CodeSystem**

iOS Lifestyle Medicine Implementation Guide - Compilação de desenvolvimento local (v0.1.0) construída pelas ferramentas de compilação FHIR (HL7® FHIR® Standard). Veja o [Diretório de versões publicadas](https://2rdoc.pt/ig/ios-lifestyle-medicine/history.html)

*  [Narrative Content](#) 
*  [XML](CodeSystem-hscrp-risk-cs.xml.md) 
*  [JSON](CodeSystem-hscrp-risk-cs.json.md) 
*  [TTL](CodeSystem-hscrp-risk-cs.ttl.md) 

## CodeSystem: hs-CRP Cardiovascular Risk CodeSystem 

| | |
| :--- | :--- |
| *Official URL*:https://2rdoc.pt/ig/ios-lifestyle-medicine/CodeSystem/hscrp-risk-cs | *Version*:0.1.0 |
| Active as of 2025-11-28 | *Computable Name*:HsCRPRiskCS |

 
Cardiovascular risk classification based on high-sensitivity C-Reactive Protein levels. 
Based on AHA/CDC Scientific Statement on Markers of Inflammation and Cardiovascular Disease: 
* Pearson TA, et al. Circulation. 2003;107(3):499-511. doi:10.1161/01.CIR.0000052939.59093.45
* Ridker PM, et al. Circulation. 2003;107(3):363-369. doi:10.1161/01.CIR.0000053730.47739.3C
 
Risk stratification thresholds: 
* Low risk: hs-CRP < 1.0 mg/L
* Average risk: hs-CRP 1.0-3.0 mg/L
* High risk: hs-CRP > 3.0 mg/L
 
Note: No SNOMED-CT codes exist for this specific clinical classification as of 2025. This CodeSystem follows thesis semantic hierarchy Level 3: local codes with documented source and migration pathway when standard terminology becomes available. 
Future migration: Monitor SNOMED-CT International Edition for cardiovascular risk finding codes. 

 
Enable structured capture of cardiovascular risk stratification based on hs-CRP levels per AHA/CDC guidelines 

 This Code system is referenced in the content logical definition of the following value sets: 

* [HsCRPInterpretationVS](ValueSet-hscrp-interpretation-vs.md)

Este sistema de código define o seguinte código:

 IG © 2024+ [Ricardo Lourenço dos Santos](https://linktr.ee/ricardolsantos). Package iOS-Lifestyle-Medicine#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-11-28 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

