# Reproductive Health to LOINC Mapping - iOS Lifestyle Medicine Implementation Guide v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Reproductive Health to LOINC Mapping**

iOS Lifestyle Medicine Implementation Guide - Compilação de desenvolvimento local (v0.1.0) construída pelas ferramentas de compilação FHIR (HL7® FHIR® Standard). Veja o [Diretório de versões publicadas](https://2rdoc.pt/ig/ios-lifestyle-medicine/history.html)

*  [Narrative Content](#) 
*  [XML](ConceptMap-ConceptMapReproductiveToLOINC.xml.md) 
*  [JSON](ConceptMap-ConceptMapReproductiveToLOINC.json.md) 
*  [TTL](ConceptMap-ConceptMapReproductiveToLOINC.ttl.md) 

## ConceptMap: Reproductive Health to LOINC Mapping 

| | |
| :--- | :--- |
| *Official URL*:https://2rdoc.pt/ig/ios-lifestyle-medicine/ConceptMap/ConceptMapReproductiveToLOINC | *Version*:0.1.0 |
| Active as of 2025-11-22 | *Computable Name*:ConceptMapReproductiveToLOINC |

 
Operational ConceptMap for reproductive health terminology translation. Enables runtime $translate operations for semantic interoperability between consumer fertility tracking applications and LOINC standard terminology. 

 
Provides semantic mappings from custom reproductive health codes to standard LOINC codes. Consumer fertility tracking apps capture ovulation status, menstrual cycle data, but use proprietary coding systems. 

Mapeamento de [Lifestyle Medicine Observation Value Set](ValueSet-lifestyle-observation-vs.md) para [LOINC Observation Codes for Lifestyle Medicine](ValueSet-loinc-observations-vs.md)

**Grupo 1**Mapeamento de [Lifestyle Medicine Observation Codes](CodeSystem-lifestyle-observation-cs.md) to [Logical Observation Identifiers, Names and Codes (LOINC)](http://terminology.hl7.org/6.5.0/CodeSystem-v3-loinc.html)

* **Código fonte**: ovulation-status
  * **Relacionamento**: (not mapped)
  * **Código de destino**: No direct LOINC code for consumer fertility device ovulation status as of November 2025. LOINC has laboratory ovulation predictor tests (e.g., LH surge tests) but not consumer device algorithmic ovulation predictions. Consumer apps use basal body temperature + symptom tracking algorithms. Terminology gap between laboratory ovulation testing and consumer fertility tracking.

 IG © 2024+ [Ricardo Lourenço dos Santos](https://linktr.ee/ricardolsantos). Package iOS-Lifestyle-Medicine#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-11-27 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

