# FHIR Resource to openEHR Archetype Mapping - iOS Lifestyle Medicine Implementation Guide v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **FHIR Resource to openEHR Archetype Mapping**

iOS Lifestyle Medicine Implementation Guide - Compilação de desenvolvimento local (v0.1.0) construída pelas ferramentas de compilação FHIR (HL7® FHIR® Standard). Veja o [Diretório de versões publicadas](https://2rdoc.pt/ig/ios-lifestyle-medicine/history.html)

*  [Narrative Content](#) 
*  [XML](ConceptMap-ConceptMapFHIRToOpenEHR.xml.md) 
*  [JSON](ConceptMap-ConceptMapFHIRToOpenEHR.json.md) 
*  [TTL](ConceptMap-ConceptMapFHIRToOpenEHR.ttl.md) 

## ConceptMap: FHIR Resource to openEHR Archetype Mapping 

| | |
| :--- | :--- |
| *Official URL*:https://2rdoc.pt/ig/ios-lifestyle-medicine/ConceptMap/ConceptMapFHIRToOpenEHR | *Version*:0.1.0 |
| Active as of 2025-11-25 | *Computable Name*:ConceptMapFHIRToOpenEHR |

 
Reverse mapping from FHIR R4 resources to custom openEHR archetypes for wearable lifestyle medicine data. 
Supported FHIR → openEHR mappings: 
* Observation (HRV profile) → OBSERVATION.heart_rate_variability.v0
* Observation (activity profile) → OBSERVATION.physical_activity_detailed.v0
* Observation (sleep profile) → OBSERVATION.sleep_architecture.v0
* Device → CLUSTER.wearable_device.v0
 
Architecture: 
* Complements ConceptMapOpenEHRToFHIR for bidirectional transformation
* Compatible with NUM-FHIR-Bridge Apache Camel routes
* Supports EHRbase CDR as target system
 

 
Enable data transformation from FHIR servers to openEHR Clinical Data Repositories (CDRs) for wearable health data in Learning Health Systems. 

Mapeamento de (não especificado) para (não especificado)

**Grupo 1**Mapeamento de [Observation](http://hl7.org/fhir/R4/observation.html) to `openEHR-EHR-OBSERVATION.heart_rate_variability.v0`

* **Código fonte**: Observation.component:sdnn (SDNN component with LOINC 80404-7)
  * **Relacionamento**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Código de destino**: id5 (SDNN - Standard deviation of NN intervals)
  * **Comentário**: Map from Observation.component with code LOINC 80404-7. Unit: ms
* **Código fonte**: Observation.component:rmssd (RMSSD component with HeartRateVariabilityCS#hrv-rmssd)
  * **Relacionamento**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Código de destino**: id6 (RMSSD - Root mean square of successive differences)
  * **Comentário**: Map from component with HeartRateVariabilityCS#hrv-rmssd. No LOINC code. Unit: ms
* **Código fonte**: Observation.component:pnn50 (pNN50 component with HeartRateVariabilityCS#hrv-pnn50)
  * **Relacionamento**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Código de destino**: id7 (pNN50 - Percentage of NN intervals >50ms)
  * **Comentário**: Map from component with HeartRateVariabilityCS#hrv-pnn50. Unit: %
* **Código fonte**: Observation.component:lf-hf-ratio (LF/HF ratio component)
  * **Relacionamento**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Código de destino**: id13 (LF/HF Ratio)
  * **Comentário**: Map from component with HeartRateVariabilityCS#hrv-lf-hf-ratio. Dimensionless ratio
* **Código fonte**: Observation.effectivePeriod (Observation.effectivePeriod (start/end))
  * **Relacionamento**: [is related to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#relatedto)
  * **Código de destino**: id32 (Recording duration)
  * **Comentário**: Calculate duration from effectivePeriod.end - effectivePeriod.start
* **Código fonte**: Observation.component:state (Physiological state component)
  * **Relacionamento**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Código de destino**: id41 (Physiological state)
  * **Comentário**: Map resting/active/sleep states from component
* **Código fonte**: Observation.device (Observation.device reference)
  * **Relacionamento**: [is related to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#relatedto)
  * **Código de destino**: id51 (Device type)
  * **Comentário**: Resolve Device reference and map to CLUSTER.wearable_device

-------

**Grupo 2**Mapeamento de [Observation](http://hl7.org/fhir/R4/observation.html) to `openEHR-EHR-OBSERVATION.physical_activity_detailed.v0`

* **Código fonte**: Observation.valueQuantity (Observation.valueQuantity (steps))
  * **Relacionamento**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Código de destino**: id10 (Step count)
  * **Comentário**: When Observation.code is LOINC 55423-8 (Number of steps). Unit: steps
* **Código fonte**: Observation.component:distance (Distance component with LOINC 55430-3)
  * **Relacionamento**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Código de destino**: id11 (Distance)
  * **Comentário**: Map from component with LOINC 55430-3. Unit: km or m
* **Código fonte**: Observation.component:active-calories (Active calories component with LOINC 41979-6)
  * **Relacionamento**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Código de destino**: id20 (Active calories)
  * **Comentário**: Map from component with LOINC 41979-6. Unit: kcal
* **Código fonte**: Observation.component:moderate-minutes (Moderate activity minutes with LOINC 77592-4)
  * **Relacionamento**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Código de destino**: id32 (Moderately active minutes)
  * **Comentário**: Map from component with LOINC 77592-4. Unit: min
* **Código fonte**: Observation.component:vigorous-minutes (Vigorous activity minutes with LOINC 77593-2)
  * **Relacionamento**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Código de destino**: id33 (Vigorously active minutes)
  * **Comentário**: Map from component with LOINC 77593-2. Unit: min

-------

**Grupo 3**Mapeamento de [Observation](http://hl7.org/fhir/R4/observation.html) to `openEHR-EHR-OBSERVATION.sleep_architecture.v0`

* **Código fonte**: Observation.valueQuantity (Observation.valueQuantity (sleep duration))
  * **Relacionamento**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Código de destino**: id13 (Total sleep time)
  * **Comentário**: When Observation.code is LOINC 93832-4 (Sleep duration). Unit: h or min
* **Código fonte**: Observation.component:deep-sleep (Deep sleep duration component)
  * **Relacionamento**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Código de destino**: id23 (Deep sleep duration)
  * **Comentário**: N3/SWS stage duration. Custom code - no LOINC
* **Código fonte**: Observation.component:rem-sleep (REM sleep duration component)
  * **Relacionamento**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Código de destino**: id24 (REM sleep duration)
  * **Comentário**: REM stage duration. Custom code - no LOINC
* **Código fonte**: Observation.component:efficiency (Sleep efficiency component)
  * **Relacionamento**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Código de destino**: id30 (Sleep efficiency)
  * **Comentário**: TST/TIB ratio as percentage. Custom code - no LOINC
* **Código fonte**: Observation.component:score (Sleep score component)
  * **Relacionamento**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Código de destino**: id40 (Sleep score)
  * **Comentário**: Vendor-specific composite score (0-100). Proprietary algorithm
* **Código fonte**: Observation.component:sleep-hrv (Average HRV during sleep component)
  * **Relacionamento**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Código de destino**: id53 (Average HRV (RMSSD) during sleep)
  * **Comentário**: Use HeartRateVariabilityCS#hrv-rmssd with context. Unit: ms

-------

**Grupo 4**Mapeamento de [Device](http://hl7.org/fhir/R4/device.html) to `openEHR-EHR-CLUSTER.wearable_device.v0`

* **Código fonte**: Device.manufacturer
  * **Relacionamento**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Código de destino**: id2 (Device platform)
  * **Comentário**: Map manufacturer string to vendor code (Apple, Fitbit, Garmin, etc.)
* **Código fonte**: Device.modelNumber
  * **Relacionamento**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Código de destino**: id3 (Device model)
  * **Comentário**: Specific model name
* **Código fonte**: Device.type
  * **Relacionamento**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Código de destino**: id4 (Device category)
  * **Comentário**: Map from SNOMED CT device type codes where available
* **Código fonte**: Device.serialNumber
  * **Relacionamento**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Código de destino**: id23 (Serial number)
  * **Comentário**: 
* **Código fonte**: Device.version:firmware (Device.version[firmware])
  * **Relacionamento**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Código de destino**: id20 (Firmware version)
  * **Comentário**: Filter by version.type = firmware

 IG © 2024+ [Ricardo Lourenço dos Santos](https://linktr.ee/ricardolsantos). Package iOS-Lifestyle-Medicine#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-11-27 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

