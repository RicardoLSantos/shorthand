# iOS Physical Activity to SNOMED CT Mapping - iOS Lifestyle Medicine Implementation Guide v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **iOS Physical Activity to SNOMED CT Mapping**

iOS Lifestyle Medicine Implementation Guide - Compilação de desenvolvimento local (v0.1.0) construída pelas ferramentas de compilação FHIR (HL7® FHIR® Standard). Veja o [Diretório de versões publicadas](https://2rdoc.pt/ig/ios-lifestyle-medicine/history.html)

*  [Narrative Content](#) 
*  [XML](ConceptMap-ConceptMapPhysicalActivityToSNOMED.xml.md) 
*  [JSON](ConceptMap-ConceptMapPhysicalActivityToSNOMED.json.md) 
*  [TTL](ConceptMap-ConceptMapPhysicalActivityToSNOMED.ttl.md) 

## ConceptMap: iOS Physical Activity to SNOMED CT Mapping 

| | |
| :--- | :--- |
| *Official URL*:https://2rdoc.pt/ig/ios-lifestyle-medicine/ConceptMap/ConceptMapPhysicalActivityToSNOMED | *Version*:0.1.0 |
| Active as of 2025-11-22 | *Computable Name*:ConceptMapPhysicalActivityToSNOMED |

 
Operational ConceptMap for physical activity terminology translation. Enables runtime $translate operations for semantic interoperability between Apple HealthKit activity types and SNOMED CT standard terminology. Critical for iOS Health App data integration into EHR systems. 

 
Provides semantic mappings from Apple HealthKit physical activity types (HKWorkoutActivityType) to standard SNOMED CT codes. Enables clinical decision support systems to interpret wearable device activity data using standardized terminology. 

Mapeamento de (não especificado) para (não especificado)

**Grupo 1**Mapeamento de [iOS Physical Activity CodeSystem](CodeSystem-ios-physical-activity-cs.md) to [SNOMED CT (all versions)](http://hl7.org/fhir/R4/codesystem-snomedct.html)

* **Código fonte**: walking
  * **Relacionamento**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Código de destino**: 129006008 (Walking (observable entity))
  * **Comentário**: Direct mapping from HKWorkoutActivityType.walking to SNOMED CT. Includes both indoor and outdoor walking activities.
* **Código fonte**: running
  * **Relacionamento**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Código de destino**: 229065009 (Running (observable entity))
  * **Comentário**: Direct mapping from HKWorkoutActivityType.running to SNOMED CT. Includes both indoor and outdoor running activities.
* **Código fonte**: cycling
  * **Relacionamento**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Código de destino**: 266940006 (Cycling (regime/therapy))
  * **Comentário**: Direct mapping from HKWorkoutActivityType.cycling to SNOMED CT. Includes outdoor cycling and stationary cycling.
* **Código fonte**: swimming
  * **Relacionamento**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Código de destino**: 266938001 (Swimming (regime/therapy))
  * **Comentário**: Direct mapping from HKWorkoutActivityType.swimming to SNOMED CT. Includes pool and open water swimming.
* **Código fonte**: hiking
  * **Relacionamento**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Código de destino**: 71537002 (Hiking (physical activity))
  * **Comentário**: Mapping from HKWorkoutActivityType.hiking to SNOMED CT code 71537002. Note: SNOMED code should be verified via official SNOMED CT Browser before clinical use.
* **Código fonte**: yoga
  * **Relacionamento**: [maps to wider concept](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#wider)
  * **Código de destino**: 48761009 (Regular exercise (regime/therapy))
  * **Comentário**: HKWorkoutActivityType.yoga maps to broader SNOMED concept 'Regular exercise'. Specific SNOMED code for yoga may exist but requires verification. Equivalence marked as 'wider' because target concept is less specific than source.
* **Código fonte**: dancing
  * **Relacionamento**: [maps to wider concept](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#wider)
  * **Código de destino**: 48761009 (Regular exercise (regime/therapy))
  * **Comentário**: HKWorkoutActivityType.dance/socialDance maps to broader SNOMED concept 'Regular exercise'. Specific SNOMED code for dancing may exist (search: 'dancing' in SNOMED CT Browser).
* **Código fonte**: strength-training
  * **Relacionamento**: [narrower](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#narrower)
  * **Código de destino**: 229070001 (Exercise training (regime/therapy))
  * **Comentário**: HKWorkoutActivityType.traditionalStrengthTraining maps to broader SNOMED concept 'Exercise training'. Target is less specific than source (which specifies strength/resistance training).
* **Código fonte**: tennis
  * **Relacionamento**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Código de destino**: 85098004 (Tennis (physical activity))
  * **Comentário**: Mapping from HKWorkoutActivityType.tennis to SNOMED CT code 85098004. Note: SNOMED code should be verified via official SNOMED CT Browser.
* **Código fonte**: badminton
  * **Relacionamento**: (not mapped)
  * **Código de destino**: No verified SNOMED CT code available for badminton as of 2025-11-22. Recommend searching SNOMED CT Browser or mapping to broader concept 'Racket sports' if available.
* **Código fonte**: squash
  * **Relacionamento**: (not mapped)
  * **Código de destino**: No verified SNOMED CT code available for squash as of 2025-11-22. Recommend searching SNOMED CT Browser or mapping to broader concept 'Racket sports'.
* **Código fonte**: table-tennis
  * **Relacionamento**: (not mapped)
  * **Código de destino**: No verified SNOMED CT code available for table tennis as of 2025-11-22. Recommend searching SNOMED CT Browser or mapping to broader concept 'Racket sports'.
* **Código fonte**: soccer
  * **Relacionamento**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Código de destino**: 81598007 (Football (physical activity))
  * **Comentário**: Mapping from HKWorkoutActivityType.soccer to SNOMED CT code 81598007 (Football). Note: SNOMED code should be verified. Regional terminology note: 'Football' in SNOMED may refer to soccer/association football.
* **Código fonte**: basketball
  * **Relacionamento**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Código de destino**: 25999001 (Basketball (physical activity))
  * **Comentário**: Mapping from HKWorkoutActivityType.basketball to SNOMED CT code 25999001. Note: SNOMED code should be verified via official SNOMED CT Browser.
* **Código fonte**: volleyball
  * **Relacionamento**: (not mapped)
  * **Código de destino**: No verified SNOMED CT code available for volleyball as of 2025-11-22. Recommend searching SNOMED CT Browser or mapping to broader concept 'Team sports'.
* **Código fonte**: tai-chi
  * **Relacionamento**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Código de destino**: 418818004 (Tai chi (regime/therapy))
  * **Comentário**: Mapping from HKWorkoutActivityType.taiChi to SNOMED CT code 418818004. Note: SNOMED code should be verified.
* **Código fonte**: pilates
  * **Relacionamento**: (not mapped)
  * **Código de destino**: No verified SNOMED CT code available for Pilates as of 2025-11-22. May map to broader concept 'Exercise training' or 'Mind-body therapy'.
* **Código fonte**: rowing
  * **Relacionamento**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Código de destino**: 10335005 (Rowing (physical activity))
  * **Comentário**: Mapping from HKWorkoutActivityType.rowing to SNOMED CT code 10335005. Note: SNOMED code should be verified.
* **Código fonte**: paddle-sports
  * **Relacionamento**: [maps to wider concept](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#wider)
  * **Código de destino**: 48761009 (Regular exercise (regime/therapy))
  * **Comentário**: HKWorkoutActivityType.paddleSports (kayaking, canoeing) maps to broader SNOMED concept 'Regular exercise'. Specific codes for paddle sports may exist.
* **Código fonte**: skiing
  * **Relacionamento**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Código de destino**: 71537001 (Skiing (physical activity))
  * **Comentário**: Mapping from HKWorkoutActivityType.downhillSkiing/crossCountrySkiing to SNOMED CT code 71537001. Note: SNOMED code should be verified. May need separate codes for downhill vs cross-country.
* **Código fonte**: snowboarding
  * **Relacionamento**: (not mapped)
  * **Código de destino**: No verified SNOMED CT code available for snowboarding as of 2025-11-22. Recommend searching SNOMED CT Browser or mapping to broader concept 'Winter sports'.
* **Código fonte**: climbing
  * **Relacionamento**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Código de destino**: 15128009 (Climbing (physical activity))
  * **Comentário**: Mapping from HKWorkoutActivityType.climbing to SNOMED CT code 15128009. Note: SNOMED code should be verified.
* **Código fonte**: golf
  * **Relacionamento**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Código de destino**: 49774004 (Golf (physical activity))
  * **Comentário**: Mapping from HKWorkoutActivityType.golf to SNOMED CT code 49774004. Note: SNOMED code should be verified.
* **Código fonte**: elliptical
  * **Relacionamento**: [narrower](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#narrower)
  * **Código de destino**: 229070001 (Exercise training (regime/therapy))
  * **Comentário**: HKWorkoutActivityType.elliptical maps to broader SNOMED concept 'Exercise training'. Specific SNOMED code for elliptical trainer may not exist.
* **Código fonte**: stairs
  * **Relacionamento**: [narrower](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#narrower)
  * **Código de destino**: 15128009 (Climbing (physical activity))
  * **Comentário**: HKWorkoutActivityType.stairs/stairStepper maps to SNOMED concept 'Climbing'. Target is broader than source (stairs is a specific type of climbing activity).

 IG © 2024+ [Ricardo Lourenço dos Santos](https://linktr.ee/ricardolsantos). Package iOS-Lifestyle-Medicine#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-11-27 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

