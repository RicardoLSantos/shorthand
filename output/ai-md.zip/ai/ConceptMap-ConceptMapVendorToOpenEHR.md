# Wearable Vendor API to openEHR Archetype Mapping - iOS Lifestyle Medicine Implementation Guide v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Wearable Vendor API to openEHR Archetype Mapping**

iOS Lifestyle Medicine Implementation Guide - Compilação de desenvolvimento local (v0.1.0) construída pelas ferramentas de compilação FHIR (HL7® FHIR® Standard). Veja o [Diretório de versões publicadas](https://2rdoc.pt/ig/ios-lifestyle-medicine/history.html)

*  [Narrative Content](#) 
*  [XML](ConceptMap-ConceptMapVendorToOpenEHR.xml.md) 
*  [JSON](ConceptMap-ConceptMapVendorToOpenEHR.json.md) 
*  [TTL](ConceptMap-ConceptMapVendorToOpenEHR.ttl.md) 

## ConceptMap: Wearable Vendor API to openEHR Archetype Mapping 

| | |
| :--- | :--- |
| *Official URL*:https://2rdoc.pt/ig/ios-lifestyle-medicine/ConceptMap/ConceptMapVendorToOpenEHR | *Version*:0.1.0 |
| Active as of 2025-11-25 | *Computable Name*:ConceptMapVendorToOpenEHR |

 
Direct mapping from proprietary wearable vendor API data types to openEHR archetypes. 
Supported Vendors: 
* Apple HealthKit (HKQuantityType, HKCategoryType)
* Fitbit Web API (activities, sleep, hrv endpoints)
* Oura Ring API (readiness, sleep, activity)
* Garmin Connect API (activities, wellness, sleep)
* Polar Flow API (training, recovery)
 
Architecture: 
* Enables direct ETL from vendor export to EHRbase CDR
* Normalizes proprietary units to UCUM
* Handles vendor-specific scoring algorithms
* Documents transformation caveats and data quality considerations
 
Use Cases: 
* Patient-generated health data (PGHD) capture
* Multi-vendor data aggregation
* Longitudinal wearable data repositories
 

 
Enable standardized capture of wearable data from multiple vendors into openEHR Clinical Data Repositories via direct ETL pipelines. 

Mapeamento de https://2rdoc.pt/ig/ios-lifestyle-medicine/vendor-apis para https://ckm.openehr.org/ckm

**Grupo 1**Mapeamento de `com.apple.health` to `openEHR-EHR-OBSERVATION.heart_rate_variability.v0`

* **Código fonte**: HKQuantityTypeIdentifierHeartRateVariabilitySDNN (Apple HealthKit: Heart Rate Variability SDNN)
  * **Relacionamento**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Código de destino**: id5 (SDNN - Standard deviation of NN intervals)
  * **Comentário**: HealthKit provides SDNN in milliseconds. Direct mapping. Note: Apple uses proprietary algorithm from PPG.
* **Código fonte**: HKQuantityTypeIdentifierHeartRate (Apple HealthKit: Heart Rate)
  * **Relacionamento**: [is related to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#relatedto)
  * **Código de destino**: id50 (Mean heart rate during recording)
  * **Comentário**: Use mean HR from same recording period for HRV context. Unit: bpm

-------

**Grupo 2**Mapeamento de `com.fitbit.hrv` to `openEHR-EHR-OBSERVATION.heart_rate_variability.v0`

* **Código fonte**: dailyRmssd (Fitbit: Daily RMSSD average)
  * **Relacionamento**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Código de destino**: id6 (RMSSD - Root mean square of successive differences)
  * **Comentário**: Fitbit provides daily RMSSD average. CAUTION: This is AVERAGED across deep sleep periods, not a single measurement.
* **Código fonte**: deepRmssd (Fitbit: Deep sleep RMSSD)
  * **Relacionamento**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Código de destino**: id6 (RMSSD during deep sleep)
  * **Comentário**: Fitbit provides RMSSD specifically from deep sleep stages. Set physiological_state (id41) = 'sleep'
* **Código fonte**: coverage (Fitbit: HRV data coverage percentage)
  * **Relacionamento**: [is related to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#relatedto)
  * **Código de destino**: id60 (Data quality indicator)
  * **Comentário**: Percentage of night with valid HRV data. Use as quality indicator. <80% suggests poor data quality.

-------

**Grupo 3**Mapeamento de `com.ouraring` to `openEHR-EHR-OBSERVATION.heart_rate_variability.v0`

* **Código fonte**: average_hrv (Oura: Average nightly HRV (RMSSD))
  * **Relacionamento**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Código de destino**: id6 (RMSSD - Root mean square of successive differences)
  * **Comentário**: Oura provides nightly average RMSSD. Measured during sleep. Unit: ms. Set physiological_state = 'sleep'
* **Código fonte**: hrv_balance (Oura: HRV Balance score)
  * **Relacionamento**: [is related to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#relatedto)
  * **Código de destino**: id70 (Vendor-specific recovery score)
  * **Comentário**: PROPRIETARY: Oura HRV Balance is a 7-day trend normalized score. NOT comparable to raw RMSSD.
* **Código fonte**: readiness_score (Oura: Readiness Score)
  * **Relacionamento**: [is related to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#relatedto)
  * **Código de destino**: id71 (Vendor-specific readiness score)
  * **Comentário**: PROPRIETARY: Composite score including HRV, sleep, activity, temperature. Scale 0-100. NOT suitable for cross-vendor comparison.

-------

**Grupo 4**Mapeamento de `com.garmin.connect` to `openEHR-EHR-OBSERVATION.heart_rate_variability.v0`

* **Código fonte**: avgHrv (Garmin: Average overnight HRV)
  * **Relacionamento**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Código de destino**: id6 (RMSSD - Root mean square of successive differences)
  * **Comentário**: Garmin provides average overnight RMSSD. Set physiological_state = 'sleep'. Unit: ms
* **Código fonte**: stressLevel (Garmin: Stress Level)
  * **Relacionamento**: [is related to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#relatedto)
  * **Código de destino**: id72 (Vendor-specific stress score)
  * **Comentário**: PROPRIETARY: Garmin stress level is DERIVED from HRV. Scale 0-100 (inverted: low = relaxed). Formula not disclosed.
* **Código fonte**: hrvStatus (Garmin: HRV Status)
  * **Relacionamento**: [is related to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#relatedto)
  * **Código de destino**: id73 (Vendor-specific HRV status)
  * **Comentário**: Categorical status: Low, Balanced, High. Relative to personal baseline. PROPRIETARY algorithm.

-------

**Grupo 5**Mapeamento de `com.polar` to `openEHR-EHR-OBSERVATION.heart_rate_variability.v0`

* **Código fonte**: hrv_rmssd (Polar: HRV RMSSD)
  * **Relacionamento**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Código de destino**: id6 (SDNN - Standard deviation of NN intervals)
  * **Comentário**: Polar H10 provides RMSSD from ECG (gold standard). Higher accuracy than PPG-based wearables. Unit: ms
* **Código fonte**: hrv_sdnn (Polar: HRV SDNN)
  * **Relacionamento**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Código de destino**: id5
  * **Comentário**: Polar provides SDNN from ECG. High accuracy. Unit: ms
* **Código fonte**: hrv_pnn50 (Polar: HRV pNN50)
  * **Relacionamento**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Código de destino**: id7 (pNN50 - Percentage of NN intervals >50ms)
  * **Comentário**: Polar provides pNN50 from ECG. Unit: percentage (0-100)

-------

**Grupo 6**Mapeamento de `com.apple.health` to `openEHR-EHR-OBSERVATION.sleep_architecture.v0`

* **Código fonte**: HKCategoryValueSleepAnalysisAsleepCore (Apple HealthKit: Core Sleep)
  * **Relacionamento**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Código de destino**: id21 (Light sleep duration (N1+N2))
  * **Comentário**: Apple 'Core' sleep maps to light sleep (N1+N2 equivalent). watchOS 9+.
* **Código fonte**: HKCategoryValueSleepAnalysisAsleepDeep (Apple HealthKit: Deep Sleep)
  * **Relacionamento**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Código de destino**: id23 (Deep sleep duration (N3/SWS))
  * **Comentário**: Apple 'Deep' sleep maps to N3/SWS. watchOS 9+.
* **Código fonte**: HKCategoryValueSleepAnalysisAsleepREM (Apple HealthKit: REM Sleep)
  * **Relacionamento**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Código de destino**: id24 (REM sleep duration)
  * **Comentário**: Apple 'REM' sleep maps directly. watchOS 9+.
* **Código fonte**: HKCategoryValueSleepAnalysisAwake (Apple HealthKit: Awake during sleep)
  * **Relacionamento**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Código de destino**: id20 (Awake time during sleep period)
  * **Comentário**: Contributes to WASO (Wake After Sleep Onset) calculation.

-------

**Grupo 7**Mapeamento de `com.apple.health` to `openEHR-EHR-OBSERVATION.physical_activity_detailed.v0`

* **Código fonte**: HKQuantityTypeIdentifierStepCount (Apple HealthKit: Step Count)
  * **Relacionamento**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Código de destino**: id10 (Step count)
  * **Comentário**: Direct mapping. Unit: count. Aggregate daily total.
* **Código fonte**: HKQuantityTypeIdentifierDistanceWalkingRunning (Apple HealthKit: Distance Walking/Running)
  * **Relacionamento**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Código de destino**: id11 (Distance)
  * **Comentário**: Convert from meters to km if needed. Aggregate daily total.
* **Código fonte**: HKQuantityTypeIdentifierActiveEnergyBurned (Apple HealthKit: Active Energy Burned)
  * **Relacionamento**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Código de destino**: id20 (Active calories)
  * **Comentário**: HealthKit provides in kilocalories (kcal). Direct mapping.
* **Código fonte**: HKQuantityTypeIdentifierAppleExerciseTime (Apple HealthKit: Exercise Time)
  * **Relacionamento**: [maps to wider concept](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#wider)
  * **Código de destino**: id35 (Exercise session duration)
  * **Comentário**: Apple Exercise Time threshold: HR > ~60-70% of estimated max. Maps to moderate+vigorous combined.

 IG © 2024+ [Ricardo Lourenço dos Santos](https://linktr.ee/ricardolsantos). Package iOS-Lifestyle-Medicine#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-11-27 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

