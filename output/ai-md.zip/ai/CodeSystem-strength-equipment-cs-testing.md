# Strength Equipment CodeSystem - Testing - iOS Lifestyle Medicine Implementation Guide v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Strength Equipment CodeSystem**

iOS Lifestyle Medicine Implementation Guide - Compilação de desenvolvimento local (v0.1.0) construída pelas ferramentas de compilação FHIR (HL7® FHIR® Standard). Veja o [Diretório de versões publicadas](https://2rdoc.pt/ig/ios-lifestyle-medicine/history.html)

*  [Narrative Content](CodeSystem-strength-equipment-cs.md) 
*  [XML](CodeSystem-strength-equipment-cs.xml.md) 
*  [JSON](CodeSystem-strength-equipment-cs.json.md) 
*  [TTL](CodeSystem-strength-equipment-cs.ttl.md) 

## CodeSystem: Strength Equipment CodeSystem - Testing 

| |
| :--- |
| Active as of 2025-11-28 |

### Test Plans

**No test plans are currently available for the CodeSystem.**

### Test Scripts

**No test scripts are currently available for the CodeSystem.**

 IG © 2024+ [Ricardo Lourenço dos Santos](https://linktr.ee/ricardolsantos). Package iOS-Lifestyle-Medicine#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-11-28 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

