# UV Exposure Measurement Example - iOS Lifestyle Medicine Implementation Guide v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **UV Exposure Measurement Example**

iOS Lifestyle Medicine Implementation Guide - Compilação de desenvolvimento local (v0.1.0) construída pelas ferramentas de compilação FHIR (HL7® FHIR® Standard). Veja o [Diretório de versões publicadas](https://2rdoc.pt/ig/ios-lifestyle-medicine/history.html)

*  [Narrative Content](#) 
*  [XML](Observation-UVExposureExample.xml.md) 
*  [JSON](Observation-UVExposureExample.json.md) 
*  [TTL](Observation-UVExposureExample.ttl.md) 

## Example Observation: UV Exposure Measurement Example

Perfil: [UV Exposure Observation Profile](StructureDefinition-uv-exposure-observation.md)

Etiqueta de segurança: normal (Pormenores: Confidentiality código N = 'normal')

**status**: Final

**category**: Survey

**code**: UV exposure duration

**subject**: [John Doe Male, DoB: 1970-01-01 ( urn:oid:2.16.858.1.1.1#12345)](Patient-PatientExample.md)

**effective**: 2024-03-19 12:00:00+0000

**note**: 

> 

Measurement taken during outdoor activity


**method**: Measured

**device**: [Device: status = active; manufacturer = Apple Inc.; modelNumber = iPhone 15 Pro; type = Application programme software; note = iPhone 15 Pro running iOS 17.0 - Apple Inc. - iOS Health App data collection device](Device-iphone-example.md)

> **component****code**:UV index**value**: 8 index(Detalhes: UCUM código1 = '1')**interpretation**:High

> **component****code**:UV exposure duration**value**: 45 min(Detalhes: UCUM códigomin = 'min')

> **component****code**:Time of environmental exposure**value**: 2024-03-19 12:00:00+0000

> **component****code**:UV intensity**value**: 0.3 W/m2(Detalhes: UCUM códigoW/m2 = 'W/m2')

 IG © 2024+ [Ricardo Lourenço dos Santos](https://linktr.ee/ricardolsantos). Package iOS-Lifestyle-Medicine#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-02 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

