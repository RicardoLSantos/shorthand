# Default Audit Configuration - iOS Lifestyle Medicine Implementation Guide v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Default Audit Configuration**

iOS Lifestyle Medicine Implementation Guide - Compilação de desenvolvimento local (v0.1.0) construída pelas ferramentas de compilação FHIR (HL7® FHIR® Standard). Veja o [Diretório de versões publicadas](https://2rdoc.pt/ig/ios-lifestyle-medicine/history.html)

*  [Narrative Content](#) 
*  [XML](Basic-DefaultAuditConfig.xml.md) 
*  [JSON](Basic-DefaultAuditConfig.json.md) 
*  [TTL](Basic-DefaultAuditConfig.ttl.md) 

## Example Basic: Default Audit Configuration

Perfil: [Mindfulness Audit Configuration](StructureDefinition-mindfulness-audit-config.md)

**Mindfulness Audit Level**: high

**Mindfulness Audit Retention**: Nenhum ecrã para Duration (value: 90; system: http://unitsofmeasure.org; code: days)

**Mindfulness Audit Format**: structured

**code**: Audit Configuration

 IG © 2024+ [Ricardo Lourenço dos Santos](https://linktr.ee/ricardolsantos). Package iOS-Lifestyle-Medicine#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-11-28 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

