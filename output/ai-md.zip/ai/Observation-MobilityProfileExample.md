# Mobility Profile Assessment Example - iOS Lifestyle Medicine Implementation Guide v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Mobility Profile Assessment Example**

iOS Lifestyle Medicine Implementation Guide - Compilação de desenvolvimento local (v0.1.0) construída pelas ferramentas de compilação FHIR (HL7® FHIR® Standard). Veja o [Diretório de versões publicadas](https://2rdoc.pt/ig/ios-lifestyle-medicine/history.html)

*  [Narrative Content](#) 
*  [XML](Observation-MobilityProfileExample.xml.md) 
*  [JSON](Observation-MobilityProfileExample.json.md) 
*  [TTL](Observation-MobilityProfileExample.ttl.md) 

## Example Observation: Mobility Profile Assessment Example

Perfil: [Mobility Profile](StructureDefinition-mobility-profile.md)

**status**: Final

**category**: Activity

**code**: Balance assessment

**subject**: [John Doe Male, DoB: 1970-01-01 ( urn:oid:2.16.858.1.1.1#12345)](Patient-PatientExample.md)

**effective**: 2024-03-19 09:00:00+0000

**performer**: [Practitioner Jane Smith](Practitioner-PractitionerExample.md)

**device**: [Device: status = active; manufacturer = Apple Inc.; modelNumber = iPhone 15 Pro; type = Application programme software; note = iPhone 15 Pro running iOS 17.0 - Apple Inc. - iOS Health App data collection device](Device-iphone-example.md)

> **component****code**:No**value**: 82 percent(Detalhes: UCUM código% = '%')

> **component****code**:Balance assessment**value**:Normal

> **component****code**:Gait assessment**value**: 1.1 meters per second(Detalhes: UCUM códigom/s = 'm/s')

> **component****code**:Movement assessment**value**: Independent ambulation

 IG © 2024+ [Ricardo Lourenço dos Santos](https://linktr.ee/ricardolsantos). Package iOS-Lifestyle-Medicine#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-03 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

