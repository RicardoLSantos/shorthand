# Mobility Assessments to SNOMED CT Mapping - iOS Lifestyle Medicine Implementation Guide v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Mobility Assessments to SNOMED CT Mapping**

iOS Lifestyle Medicine Implementation Guide - Compilação de desenvolvimento local (v0.1.0) construída pelas ferramentas de compilação FHIR (HL7® FHIR® Standard). Veja o [Diretório de versões publicadas](https://2rdoc.pt/ig/ios-lifestyle-medicine/history.html)

*  [Narrative Content](#) 
*  [XML](ConceptMap-ConceptMapMobilityToSNOMED.xml.md) 
*  [JSON](ConceptMap-ConceptMapMobilityToSNOMED.json.md) 
*  [TTL](ConceptMap-ConceptMapMobilityToSNOMED.ttl.md) 

## ConceptMap: Mobility Assessments to SNOMED CT Mapping 

| | |
| :--- | :--- |
| *Official URL*:https://2rdoc.pt/ig/ios-lifestyle-medicine/ConceptMap/ConceptMapMobilityToSNOMED | *Version*:0.1.0 |
| Active as of 2025-11-22 | *Computable Name*:ConceptMapMobilityToSNOMED |

 
Operational ConceptMap for mobility assessment terminology translation. Enables runtime $translate operations for semantic interoperability between consumer mobility monitoring wearables and SNOMED CT standard terminology. 

 
Provides semantic mappings from custom mobility assessment codes to standard SNOMED CT codes. Consumer wearables (Apple Watch, Garmin) increasingly provide gait analysis and mobility assessments but use proprietary terminology. 

Mapeamento de (não especificado) para (não especificado)

**Grupo 1**Mapeamento de [Lifestyle Medicine Observation Codes](CodeSystem-lifestyle-observation-cs.md) to [SNOMED CT (all versions)](http://hl7.org/fhir/R4/codesystem-snomedct.html)

* **Código fonte**: gait-assessment
  * **Relacionamento**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Código de destino**: 271706000 (Gait, function (observable entity))
  * **Comentário**: Gait assessment maps to SNOMED 'Gait, function' observable entity. Code 271706000 should be verified via SNOMED CT Browser.
* **Código fonte**: balance-assessment
  * **Relacionamento**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Código de destino**: 271722003 (Balance (observable entity))
  * **Comentário**: Balance assessment maps to SNOMED 'Balance' observable entity. Code 271722003 should be verified.
* **Código fonte**: walking-steadiness (Walking steadiness measurement)
  * **Relacionamento**: [maps to wider concept](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#wider)
  * **Código de destino**: 271722003 (Balance (observable entity))
  * **Comentário**: Walking steadiness (Apple Watch metric) maps to broader SNOMED 'Balance' concept. Source is specific algorithmic measurement from accelerometer/gyroscope during walking, target is general balance concept. No exact SNOMED match for 'walking steadiness' consumer metric.
* **Código fonte**: walking-speed (Walking speed measurement)
  * **Relacionamento**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Código de destino**: 249869000 (Walking speed (observable entity))
  * **Comentário**: Walking speed maps directly to SNOMED 'Walking speed' observable entity. Code 249869000 should be verified.
* **Código fonte**: movement-assessment
  * **Relacionamento**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Código de destino**: 364555000 (Movement quality (observable entity))
  * **Comentário**: Movement assessment maps to SNOMED 'Movement quality' observable entity. Code 364555000 should be verified.

 IG © 2024+ [Ricardo Lourenço dos Santos](https://linktr.ee/ricardolsantos). Package iOS-Lifestyle-Medicine#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-11-27 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

