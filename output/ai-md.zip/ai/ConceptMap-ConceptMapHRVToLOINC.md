# Heart Rate Variability to LOINC Mapping - iOS Lifestyle Medicine Implementation Guide v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Heart Rate Variability to LOINC Mapping**

iOS Lifestyle Medicine Implementation Guide - Compilação de desenvolvimento local (v0.1.0) construída pelas ferramentas de compilação FHIR (HL7® FHIR® Standard). Veja o [Diretório de versões publicadas](https://2rdoc.pt/ig/ios-lifestyle-medicine/history.html)

*  [Narrative Content](#) 
*  [XML](ConceptMap-ConceptMapHRVToLOINC.xml.md) 
*  [JSON](ConceptMap-ConceptMapHRVToLOINC.json.md) 
*  [TTL](ConceptMap-ConceptMapHRVToLOINC.ttl.md) 

## ConceptMap: Heart Rate Variability to LOINC Mapping 

| | |
| :--- | :--- |
| *Official URL*:https://2rdoc.pt/ig/ios-lifestyle-medicine/ConceptMap/ConceptMapHRVToLOINC | *Version*:0.1.0 |
| Active as of 2024-11-21 | *Computable Name*:ConceptMapHRVToLOINC |

 
Operational ConceptMap for HRV terminology translation. Enables runtime $translate operations for semantic interoperability between custom HRV codes and LOINC standard terminology. 

 
Provides semantic mappings from custom HRV metrics to standard LOINC codes where available, with migration path for future LOINC assignments. Critical for wearable device data integration into EHR systems. 

Mapeamento de [Heart Rate Variability ValueSet](ValueSet-heart-rate-variability-vs.md) para [LOINC Observation Codes for Lifestyle Medicine](ValueSet-loinc-observations-vs.md)

**Grupo 1**Mapeamento de [Heart Rate Variability CodeSystem](CodeSystem-heart-rate-variability-cs.md) to [Logical Observation Identifiers, Names and Codes (LOINC)](http://terminology.hl7.org/6.5.0/CodeSystem-v3-loinc.html)

* **Código fonte**: hrv-sdnn (HRV SDNN (Standard Deviation of NN intervals))
  * **Relacionamento**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Código de destino**: 80404-7 (R-R interval.standard deviation (Heart rate variability))
  * **Comentário**: Confirmed LOINC code for SDNN, created in LOINC v2.72 (June 2022). Time-domain HRV measure representing total variability.
* **Código fonte**: hrv-rmssd (HRV RMSSD (Root Mean Square of Successive Differences))
  * **Relacionamento**: (not mapped)
  * **Código de destino**: No LOINC code available as of November 2024. RMSSD is the primary parasympathetic marker recommended by HRV Task Force 1996. Submission recommended to LOINC committee. NOTE: Apple HealthKit mislabels this as 'SDNN' (HKQuantityTypeIdentifierHeartRateVariabilitySDNN) - implementers should be aware of this vendor-specific naming error.
* **Código fonte**: hrv-pnn50 (HRV pNN50 (Percentage of NN intervals >50ms difference))
  * **Relacionamento**: (not mapped)
  * **Código de destino**: No LOINC code available as of November 2024. High correlation with RMSSD (r>0.90), parasympathetic marker. Percentage of successive NN intervals differing by more than 50ms.
* **Código fonte**: hrv-lf-hf-ratio (HRV LF/HF Ratio (Low Frequency to High Frequency ratio))
  * **Relacionamento**: (not mapped)
  * **Código de destino**: No LOINC code available as of November 2024. Autonomic balance indicator, though clinical interpretation is debated. Ratio of LF power (0.04-0.15 Hz) to HF power (0.15-0.4 Hz).
* **Código fonte**: hrv-lf-power (HRV LF Power (Low Frequency power 0.04-0.15 Hz))
  * **Relacionamento**: (not mapped)
  * **Código de destino**: No LOINC code available as of November 2024. Low frequency spectral power (0.04-0.15 Hz). Reflects both sympathetic and parasympathetic modulation, with some baroreflex contribution.
* **Código fonte**: hrv-hf-power (HRV HF Power (High Frequency power 0.15-0.4 Hz))
  * **Relacionamento**: (not mapped)
  * **Código de destino**: No LOINC code available as of November 2024. High frequency spectral power (0.15-0.4 Hz). Reflects parasympathetic (vagal) modulation, synchronized with respiratory rhythm.

 IG © 2024+ [Ricardo Lourenço dos Santos](https://linktr.ee/ricardolsantos). Package iOS-Lifestyle-Medicine#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-11-27 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

