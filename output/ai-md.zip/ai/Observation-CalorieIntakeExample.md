# Daily Calorie Intake Example - iOS Lifestyle Medicine Implementation Guide v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Daily Calorie Intake Example**

iOS Lifestyle Medicine Implementation Guide - Compilação de desenvolvimento local (v0.1.0) construída pelas ferramentas de compilação FHIR (HL7® FHIR® Standard). Veja o [Diretório de versões publicadas](https://2rdoc.pt/ig/ios-lifestyle-medicine/history.html)

*  [Narrative Content](#) 
*  [XML](Observation-CalorieIntakeExample.xml.md) 
*  [JSON](Observation-CalorieIntakeExample.json.md) 
*  [TTL](Observation-CalorieIntakeExample.ttl.md) 

## Example Observation: Daily Calorie Intake Example

Perfil: [Calorie Intake Observation Profile](StructureDefinition-calorie-intake-observation.md)

**status**: Final

**category**: Survey

**code**: Total caloric intake

**subject**: [John Doe Male, DoB: 1970-01-01 ( urn:oid:2.16.858.1.1.1#12345)](Patient-PatientExample.md)

**effective**: 2024-03-19 20:00:00+0000

**performer**: [Practitioner Jane Smith](Practitioner-PractitionerExample.md)

**value**: 2100 kilocalorie(Detalhes: UCUM códigokcal = 'kcal')

**note**: 

> 

Total calories consumed during the day from all meals


 IG © 2024+ [Ricardo Lourenço dos Santos](https://linktr.ee/ricardolsantos). Package iOS-Lifestyle-Medicine#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-03 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

