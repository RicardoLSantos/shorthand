# Weight Measurement with Conditions Example - iOS Lifestyle Medicine Implementation Guide v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Weight Measurement with Conditions Example**

iOS Lifestyle Medicine Implementation Guide - Compilação de desenvolvimento local (v0.1.0) construída pelas ferramentas de compilação FHIR (HL7® FHIR® Standard). Veja o [Diretório de versões publicadas](https://2rdoc.pt/ig/ios-lifestyle-medicine/history.html)

*  [Narrative Content](#) 
*  [XML](Observation-WeightWithConditions.xml.md) 
*  [JSON](Observation-WeightWithConditions.json.md) 
*  [TTL](Observation-WeightWithConditions.ttl.md) 

## Example Observation: Weight Measurement with Conditions Example

Perfil: [Weight Measurement Profile](StructureDefinition-weight-observation.md)

**Measurement Conditions Extension**: After exercise

**Measurement Device Type Extension**: Physiologic monitoring system

**status**: Final

**category**: Vital Signs

**code**: Body weight

**subject**: [Patient Example Unknown, DoB: 1970-01-01 ( http://example.org/patients#example-patient)](Patient-example.md)

**effective**: 2024-03-19 08:00:00+0000

**value**: 70.5 kilogram(Detalhes: UCUM códigokg = 'kg')

 IG © 2024+ [Ricardo Lourenço dos Santos](https://linktr.ee/ricardolsantos). Package iOS-Lifestyle-Medicine#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-02 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

