# Mindfulness Module Capabilities - iOS Lifestyle Medicine Implementation Guide v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Mindfulness Module Capabilities**

iOS Lifestyle Medicine Implementation Guide - Compilação de desenvolvimento local (v0.1.0) construída pelas ferramentas de compilação FHIR (HL7® FHIR® Standard). Veja o [Diretório de versões publicadas](https://2rdoc.pt/ig/ios-lifestyle-medicine/history.html)

*  [Narrative Content](#) 
*  [XML](CapabilityStatement-MindfulnessCapabilityStatement.xml.md) 
*  [JSON](CapabilityStatement-MindfulnessCapabilityStatement.json.md) 
*  [TTL](CapabilityStatement-MindfulnessCapabilityStatement.ttl.md) 

## CapabilityStatement: Mindfulness Module Capabilities 

| | |
| :--- | :--- |
| *Official URL*:https://2rdoc.pt/ig/ios-lifestyle-medicine/CapabilityStatement/MindfulnessCapabilityStatement | *Version*:0.1.0 |
| Draft as of 2024-03-19 | *Computable Name*: |

 
Capabilities supported by the mindfulness module implementation 

 [Raw OpenAPI-Swagger Definition file](MindfulnessCapabilityStatement.openapi.json) | [Download](MindfulnessCapabilityStatement.openapi.json) 

## Mindfulness Module Capabilities

* Guia de implementação Versão: 0.1.0 
* Versão FHIR: 4.0.1 
* Formatos suportados: `json`, `xml`
* Publicado em: 2024-03-19 
* Publicado por: Ricardo Lourenço dos Santos 

> **Nota para os implementadores: Capacidades FHIR**Qualquer capacidade FHIR pode ser \"permitida\" pelo sistema, exceto se for explicitamente assinalada como \"NÃO DEVE\". Alguns itens são marcados como MAY no Guia de Implementação para destacar a sua potencial relevância para o caso de utilização.

## Capacidades FHIR RESTful

### Mode: server

RESTful server capabilities for mindfulness data

### Capacidades por recurso/perfil

#### Resumo

A tabela de resumo enumera os recursos que fazem parte desta configuração e, para cada recurso, enumera-os:

* Os perfis relevantes (se existirem)
* As interações suportadas por cada recurso (**R**ead, **S**earch, **U**pdate, and **C**reate, are always shown, while **VR**ead, **P**atch, **D**elete, **H**istory on **I**nstance, or **H**istory on **T**só estão presentes se pelo menos um dos recursos os suportar.
* Os parâmetros de pesquisa obrigatórios, recomendados e alguns opcionais (se existirem).
* Os recursos ligados activados para `_include`
* Os outros recursos activados para `_revinclude`
* As operações sobre o recurso (se existirem)

| | | | | | | | | | |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| [Observation](#Observation1-1) | [https://2rdoc.pt/ig/ios-lifestyle-medicine/StructureDefinition/mindfulness-observation](StructureDefinition-mindfulness-observation.md) | y | y | y | y | patient, date, code |  |  |  |
| [Questionnaire](#Questionnaire1-2) |   | y | y |  |  | title |  |  |  |
| [QuestionnaireResponse](#QuestionnaireResponse1-3) |   | y | y |  | y | patient, authored |  |  |  |

-------

#### Conformidade do recurso: supported Observation

Perfil do sistema de base

[Mindfulness Session Observation](StructureDefinition-mindfulness-observation.md)

Conformidade do perfil

**SHALL**

Política de referência

Resumo da interação

* Apoios `read`, `create`, `update`, `search-type`.

Documentação
> 

Supports mindfulness session observations


Parâmetros de pesquisa


 

#### Conformidade do recurso: supported Questionnaire

Recurso FHIR principal

[Questionnaire](http://hl7.org/fhir/R4/questionnaire.html)

Política de referência

Resumo da interação

* Apoios `read`, `search-type`.

Documentação
> 

Supports mindfulness questionnaires


Parâmetros de pesquisa


 

#### Conformidade do recurso: supported QuestionnaireResponse

Recurso FHIR principal

[QuestionnaireResponse](http://hl7.org/fhir/R4/questionnaireresponse.html)

Política de referência

Resumo da interação

* Apoios `create`, `read`, `search-type`.

Documentação
> 

Supports mindfulness questionnaire responses


Parâmetros de pesquisa


 

 IG © 2024+ [Ricardo Lourenço dos Santos](https://linktr.ee/ricardolsantos). Package iOS-Lifestyle-Medicine#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-11-27 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

