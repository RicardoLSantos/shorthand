# openEHR Archetype to FHIR Resource Mapping - iOS Lifestyle Medicine Implementation Guide v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **openEHR Archetype to FHIR Resource Mapping**

iOS Lifestyle Medicine Implementation Guide - Compilação de desenvolvimento local (v0.1.0) construída pelas ferramentas de compilação FHIR (HL7® FHIR® Standard). Veja o [Diretório de versões publicadas](https://2rdoc.pt/ig/ios-lifestyle-medicine/history.html)

*  [Narrative Content](#) 
*  [XML](ConceptMap-ConceptMapOpenEHRToFHIR.xml.md) 
*  [JSON](ConceptMap-ConceptMapOpenEHRToFHIR.json.md) 
*  [TTL](ConceptMap-ConceptMapOpenEHRToFHIR.ttl.md) 

## ConceptMap: openEHR Archetype to FHIR Resource Mapping 

| | |
| :--- | :--- |
| *Official URL*:https://2rdoc.pt/ig/ios-lifestyle-medicine/ConceptMap/ConceptMapOpenEHRToFHIR | *Version*:0.1.0 |
| Active as of 2025-11-25 | *Computable Name*:ConceptMapOpenEHRToFHIR |

 
Bidirectional mapping between custom openEHR archetypes for wearable lifestyle medicine data and FHIR R4 resources. 
Supported openEHR Archetypes: 
* OBSERVATION.heart_rate_variability.v0 → Observation (vital-signs)
* OBSERVATION.physical_activity_detailed.v0 → Observation (physical-activity)
* OBSERVATION.sleep_architecture.v0 → Observation (sleep-analysis)
* CLUSTER.wearable_device.v0 → Device
 
Architecture: 
* Uses FHIRconnect triple-layer pattern (Kohler et al., 2025)
* Compatible with NUM-FHIR-Bridge Apache Camel routes
* Supports EHRbase CDR as source system
 

 
Enable round-trip data transformation between openEHR Clinical Data Repositories (CDRs) and FHIR servers for wearable health data in Learning Health Systems. 

Mapeamento de (não especificado) para (não especificado)

**Grupo 1**Mapeamento de `openEHR-EHR-OBSERVATION.heart_rate_variability.v0` to [Observation](http://hl7.org/fhir/R4/observation.html)

* **Código fonte**: id5 (SDNN - Standard deviation of NN intervals)
  * **Relacionamento**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Código de destino**: Observation.component (Observation.component[sdnn].valueQuantity)
  * **Comentário**: Map to component with code LOINC 80404-7. Unit: ms
* **Código fonte**: id6 (RMSSD - Root mean square of successive differences)
  * **Relacionamento**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Código de destino**: Observation.component (Observation.component[rmssd].valueQuantity)
  * **Comentário**: Map to component with HeartRateVariabilityCS#hrv-rmssd. No LOINC code available. Unit: ms
* **Código fonte**: id7 (pNN50 - Percentage of NN intervals >50ms)
  * **Relacionamento**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Código de destino**: Observation.component (Observation.component[pnn50].valueQuantity)
  * **Comentário**: Map to component with HeartRateVariabilityCS#hrv-pnn50. Unit: %
* **Código fonte**: id13 (LF/HF Ratio)
  * **Relacionamento**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Código de destino**: Observation.component (Observation.component[lf-hf-ratio].valueQuantity)
  * **Comentário**: Map to component with HeartRateVariabilityCS#hrv-lf-hf-ratio. Dimensionless ratio
* **Código fonte**: id32 (Recording duration)
  * **Relacionamento**: [is related to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#relatedto)
  * **Código de destino**: Observation.effectivePeriod (Observation.effectivePeriod (start/end))
  * **Comentário**: Duration derived from effectivePeriod.end - effectivePeriod.start
* **Código fonte**: id41 (Physiological state)
  * **Relacionamento**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Código de destino**: Observation.component (Observation.component[state].valueCodeableConcept)
  * **Comentário**: Map resting/active/sleep states to component with custom code
* **Código fonte**: id51 (Device type)
  * **Relacionamento**: [is related to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#relatedto)
  * **Código de destino**: Observation.device (Observation.device → Device reference)
  * **Comentário**: Reference to Device resource with wearable details

-------

**Grupo 2**Mapeamento de `openEHR-EHR-OBSERVATION.physical_activity_detailed.v0` to [Observation](http://hl7.org/fhir/R4/observation.html)

* **Código fonte**: id10 (Step count)
  * **Relacionamento**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Código de destino**: Observation.valueQuantity
  * **Comentário**: Primary value when code is LOINC 55423-8 (Number of steps). Unit: steps
* **Código fonte**: id11 (Distance)
  * **Relacionamento**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Código de destino**: Observation.component (Observation.component[distance].valueQuantity)
  * **Comentário**: Map to component with LOINC 55430-3. Unit: km or m
* **Código fonte**: id20 (Active calories)
  * **Relacionamento**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Código de destino**: Observation.component (Observation.component[active-calories].valueQuantity)
  * **Comentário**: Map to component with LOINC 41979-6. Unit: kcal
* **Código fonte**: id32 (Moderately active minutes)
  * **Relacionamento**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Código de destino**: Observation.component (Observation.component[moderate-minutes].valueQuantity)
  * **Comentário**: Map to component with LOINC 77592-4. Unit: min
* **Código fonte**: id33 (Vigorously active minutes)
  * **Relacionamento**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Código de destino**: Observation.component (Observation.component[vigorous-minutes].valueQuantity)
  * **Comentário**: Map to component with LOINC 77593-2. Unit: min

-------

**Grupo 3**Mapeamento de `openEHR-EHR-OBSERVATION.sleep_architecture.v0` to [Observation](http://hl7.org/fhir/R4/observation.html)

* **Código fonte**: id13 (Total sleep time)
  * **Relacionamento**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Código de destino**: Observation.valueQuantity
  * **Comentário**: Primary value when code is LOINC 93832-4 (Sleep duration). Unit: h or min
* **Código fonte**: id23 (Deep sleep duration)
  * **Relacionamento**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Código de destino**: Observation.component (Observation.component[deep-sleep].valueQuantity)
  * **Comentário**: N3/SWS stage duration. Custom code required - no LOINC
* **Código fonte**: id24 (REM sleep duration)
  * **Relacionamento**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Código de destino**: Observation.component (Observation.component[rem-sleep].valueQuantity)
  * **Comentário**: REM stage duration. Custom code required - no LOINC
* **Código fonte**: id30 (Sleep efficiency)
  * **Relacionamento**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Código de destino**: Observation.component (Observation.component[efficiency].valueQuantity)
  * **Comentário**: TST/TIB ratio as percentage. Custom code required - no LOINC
* **Código fonte**: id40 (Sleep score)
  * **Relacionamento**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Código de destino**: Observation.component (Observation.component[score].valueInteger)
  * **Comentário**: Vendor-specific composite score (0-100). Proprietary algorithm
* **Código fonte**: id53 (Average HRV (RMSSD) during sleep)
  * **Relacionamento**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Código de destino**: Observation.component (Observation.component[sleep-hrv].valueQuantity)
  * **Comentário**: Use HeartRateVariabilityCS#hrv-rmssd with context. Unit: ms

-------

**Grupo 4**Mapeamento de `openEHR-EHR-CLUSTER.wearable_device.v0` to [Device](http://hl7.org/fhir/R4/device.html)

* **Código fonte**: id2 (Device platform)
  * **Relacionamento**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Código de destino**: Device.manufacturer
  * **Comentário**: Map vendor code to manufacturer string (Apple, Fitbit, Garmin, etc.)
* **Código fonte**: id3 (Device model)
  * **Relacionamento**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Código de destino**: Device.modelNumber
  * **Comentário**: Specific model name
* **Código fonte**: id4 (Device category)
  * **Relacionamento**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Código de destino**: Device.type
  * **Comentário**: Map to SNOMED CT device type codes where available
* **Código fonte**: id23 (Serial number)
  * **Relacionamento**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Código de destino**: Device.serialNumber
  * **Comentário**: 
* **Código fonte**: id20 (Firmware version)
  * **Relacionamento**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Código de destino**: Device.version (Device.version[firmware])
  * **Comentário**: Use version.type = firmware

 IG © 2024+ [Ricardo Lourenço dos Santos](https://linktr.ee/ricardolsantos). Package iOS-Lifestyle-Medicine#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-11-27 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

