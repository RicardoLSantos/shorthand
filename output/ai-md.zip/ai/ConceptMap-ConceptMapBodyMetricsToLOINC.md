# Body Metrics to LOINC Mapping - iOS Lifestyle Medicine Implementation Guide v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Body Metrics to LOINC Mapping**

iOS Lifestyle Medicine Implementation Guide - Compilação de desenvolvimento local (v0.1.0) construída pelas ferramentas de compilação FHIR (HL7® FHIR® Standard). Veja o [Diretório de versões publicadas](https://2rdoc.pt/ig/ios-lifestyle-medicine/history.html)

*  [Narrative Content](#) 
*  [XML](ConceptMap-ConceptMapBodyMetricsToLOINC.xml.md) 
*  [JSON](ConceptMap-ConceptMapBodyMetricsToLOINC.json.md) 
*  [TTL](ConceptMap-ConceptMapBodyMetricsToLOINC.ttl.md) 

## ConceptMap: Body Metrics to LOINC Mapping 

| | |
| :--- | :--- |
| *Official URL*:https://2rdoc.pt/ig/ios-lifestyle-medicine/ConceptMap/ConceptMapBodyMetricsToLOINC | *Version*:0.1.0 |
| Active as of 2025-11-22 | *Computable Name*:ConceptMapBodyMetricsToLOINC |

 
Operational ConceptMap for body composition measurement terminology translation. Enables runtime $translate operations for semantic interoperability between consumer bioimpedance scales and LOINC standard terminology. 

 
Provides semantic mappings from custom body composition codes to standard LOINC codes. Consumer body composition scales measure metrics like body fat percentage, lean mass, BMI via bioimpedance analysis (BIA). 

Mapeamento de (não especificado) para (não especificado)

**Grupo 1**Mapeamento de [Lifestyle Medicine Observation Codes](CodeSystem-lifestyle-observation-cs.md) to [Logical Observation Identifiers, Names and Codes (LOINC)](http://terminology.hl7.org/6.5.0/CodeSystem-v3-loinc.html)

* **Código fonte**: body-composition-panel (Body composition measurement panel)
  * **Relacionamento**: [is related to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#relatedto)
  * **Código de destino**: 77233-5 (Percentage of body fat by Bioelectrical impedance analysis)
  * **Comentário**: LOINC has no dedicated BIA panel code. Map to individual BIA measurement codes: 77233-5 (body fat %), 73965-6 (muscle mass %), 73708-0 (fat mass). This maps to the primary BIA metric.

 IG © 2024+ [Ricardo Lourenço dos Santos](https://linktr.ee/ricardolsantos). Package iOS-Lifestyle-Medicine#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-11-27 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

