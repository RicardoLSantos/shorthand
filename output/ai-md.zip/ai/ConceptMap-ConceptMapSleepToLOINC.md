# Sleep Measurements to LOINC Mapping - iOS Lifestyle Medicine Implementation Guide v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Sleep Measurements to LOINC Mapping**

iOS Lifestyle Medicine Implementation Guide - Compilação de desenvolvimento local (v0.1.0) construída pelas ferramentas de compilação FHIR (HL7® FHIR® Standard). Veja o [Diretório de versões publicadas](https://2rdoc.pt/ig/ios-lifestyle-medicine/history.html)

*  [Narrative Content](#) 
*  [XML](ConceptMap-ConceptMapSleepToLOINC.xml.md) 
*  [JSON](ConceptMap-ConceptMapSleepToLOINC.json.md) 
*  [TTL](ConceptMap-ConceptMapSleepToLOINC.ttl.md) 

## ConceptMap: Sleep Measurements to LOINC Mapping 

| | |
| :--- | :--- |
| *Official URL*:https://2rdoc.pt/ig/ios-lifestyle-medicine/ConceptMap/ConceptMapSleepToLOINC | *Version*:0.1.0 |
| Active as of 2025-11-22 | *Computable Name*:ConceptMapSleepToLOINC |

 
Operational ConceptMap for sleep measurement terminology translation. Enables runtime $translate operations for semantic interoperability between consumer wearable device sleep data and LOINC standard terminology. Critical for integrating iOS Health App and other consumer sleep tracking platforms into EHR systems. 

 
Provides semantic mappings from custom sleep measurement codes to standard LOINC codes. Sleep tracking from consumer devices (Apple Watch, Fitbit, Oura Ring, Garmin, etc.) uses proprietary measurements not fully covered by LOINC. This ConceptMap enables clinical decision support systems to interpret consumer sleep data using standardized terminology where available. 

Mapeamento de [Lifestyle Medicine Observation Value Set](ValueSet-lifestyle-observation-vs.md) para [LOINC Observation Codes for Lifestyle Medicine](ValueSet-loinc-observations-vs.md)

**Grupo 1**Mapeamento de [Lifestyle Medicine Observation Codes](CodeSystem-lifestyle-observation-cs.md) to [Logical Observation Identifiers, Names and Codes (LOINC)](http://terminology.hl7.org/6.5.0/CodeSystem-v3-loinc.html)

* **Códigos**de[Lifestyle Medicine Observation Codes](CodeSystem-lifestyle-observation-cs.md): sleep-panel
  * : Sleep measurement panel
  * **Códigos**de[Logical Observation Identifiers, Names and Codes (LOINC)](http://terminology.hl7.org/6.5.0/CodeSystem-v3-loinc.html): [narrower](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#narrower)
  * : 90568-7
  * ?: Polysomnography panel
  * ?: Sleep measurement panel from consumer devices maps to broader LOINC Polysomnography panel. Source is more specific (consumer device panel) than target (clinical polysomnography). LOINC 90568-7 contains terms from American Academy of Sleep Medicine (AASM) guidelines. Consumer devices measure subset of clinical polysomnography parameters.
* **Códigos**de[Lifestyle Medicine Observation Codes](CodeSystem-lifestyle-observation-cs.md): 
  * : 
  * **Códigos**de[Logical Observation Identifiers, Names and Codes (LOINC)](http://terminology.hl7.org/6.5.0/CodeSystem-v3-loinc.html): [maps to wider concept](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#wider)
  * : 82611-5
  * ?: Wearable device external physiologic monitoring panel
  * ?: Alternative mapping to general wearable device panel. Target is less specific (covers all wearable physiologic monitoring) than source (sleep-specific panel).
* **Códigos**de[Lifestyle Medicine Observation Codes](CodeSystem-lifestyle-observation-cs.md): sleep-time-bed
  * : Time in bed
  * **Códigos**de[Logical Observation Identifiers, Names and Codes (LOINC)](http://terminology.hl7.org/6.5.0/CodeSystem-v3-loinc.html): (not mapped)
  * : No LOINC code available for 'Time in bed' as of November 2025. Time in bed is a distinct concept from 'Sleep duration' (LOINC 93832-4) - it includes time awake before falling asleep and after waking. Common consumer device metric (Apple HealthKit, Fitbit, Oura, etc.). Recommend submission to LOINC for standardization.
* **Códigos**de[Lifestyle Medicine Observation Codes](CodeSystem-lifestyle-observation-cs.md): sleep-deep
  * : Deep sleep duration
  * **Códigos**de[Logical Observation Identifiers, Names and Codes (LOINC)](http://terminology.hl7.org/6.5.0/CodeSystem-v3-loinc.html): (not mapped)
  * : No LOINC code available for 'Deep sleep duration' (slow-wave sleep, N3 stage) as of November 2025. Consumer devices measure deep sleep using accelerometer + heart rate algorithms, not EEG. Clinical polysomnography uses EEG-defined N3 sleep stage. Terminology gap: consumer 'deep sleep' vs clinical 'N3/slow-wave sleep'. LOINC has codes for clinical polysomnography sleep stages but not consumer device equivalents.
* **Códigos**de[Lifestyle Medicine Observation Codes](CodeSystem-lifestyle-observation-cs.md): sleep-light
  * : Light sleep duration
  * **Códigos**de[Logical Observation Identifiers, Names and Codes (LOINC)](http://terminology.hl7.org/6.5.0/CodeSystem-v3-loinc.html): (not mapped)
  * : No LOINC code available for 'Light sleep duration' (N1+N2 stages) as of November 2025. Consumer devices combine N1 and N2 sleep stages into 'light sleep' category. Clinical polysomnography separates N1 and N2. Terminology gap between consumer device simplification and clinical EEG-based staging. Widely used metric in Apple HealthKit, Fitbit, Oura Ring, Garmin wearables.
* **Códigos**de[Lifestyle Medicine Observation Codes](CodeSystem-lifestyle-observation-cs.md): sleep-awakenings
  * : Number of sleep awakenings
  * **Códigos**de[Logical Observation Identifiers, Names and Codes (LOINC)](http://terminology.hl7.org/6.5.0/CodeSystem-v3-loinc.html): [is related to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#relatedto)
  * : 103215-0
  * ?: Wake time after sleep onset
  * ?: Sleep awakenings count is related to but distinct from 'Wake time after sleep onset' (LOINC 103215-0). Source measures NUMBER of awakenings (discrete count), target measures DURATION of wakefulness after initial sleep onset (time in minutes). Both concepts assess sleep fragmentation but from different perspectives. No exact LOINC match for awakening count exists as of November 2025.

 IG © 2024+ [Ricardo Lourenço dos Santos](https://linktr.ee/ricardolsantos). Package iOS-Lifestyle-Medicine#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-11-27 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

