# Mindfulness Schedule Type - iOS Lifestyle Medicine Implementation Guide v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Mindfulness Schedule Type**

iOS Lifestyle Medicine Implementation Guide - Compilação de desenvolvimento local (v0.1.0) construída pelas ferramentas de compilação FHIR (HL7® FHIR® Standard). Veja o [Diretório de versões publicadas](https://2rdoc.pt/ig/ios-lifestyle-medicine/history.html)

*  [Narrative Content](#) 
*  [XML](CodeSystem-mindfulness-schedule-type.xml.md) 
*  [JSON](CodeSystem-mindfulness-schedule-type.json.md) 
*  [TTL](CodeSystem-mindfulness-schedule-type.ttl.md) 

## CodeSystem: Mindfulness Schedule Type 

| | |
| :--- | :--- |
| *Official URL*:https://2rdoc.pt/ig/ios-lifestyle-medicine/CodeSystem/mindfulness-schedule-type | *Version*:0.1.0 |
| Active as of 2025-11-27 | *Computable Name*:MindfulnessScheduleTypeCS |

 
Types of schedules for mindfulness practice sessions 

 This Code system is referenced in the content logical definition of the following value sets: 

* Este CodeSystem não é utilizado aqui; pode ser utilizado noutro local (por exemplo, em especificações e/ou implementações que utilizem este conteúdo)

Este sistema de código define o seguinte código:

 IG © 2024+ [Ricardo Lourenço dos Santos](https://linktr.ee/ricardolsantos). Package iOS-Lifestyle-Medicine#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-11-27 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

