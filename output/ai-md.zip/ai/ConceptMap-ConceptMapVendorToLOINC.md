# Vendor Proprietary Codes to LOINC Mapping - iOS Lifestyle Medicine Implementation Guide v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Vendor Proprietary Codes to LOINC Mapping**

iOS Lifestyle Medicine Implementation Guide - Compilação de desenvolvimento local (v0.1.0) construída pelas ferramentas de compilação FHIR (HL7® FHIR® Standard). Veja o [Diretório de versões publicadas](https://2rdoc.pt/ig/ios-lifestyle-medicine/history.html)

*  [Narrative Content](#) 
*  [XML](ConceptMap-ConceptMapVendorToLOINC.xml.md) 
*  [JSON](ConceptMap-ConceptMapVendorToLOINC.json.md) 
*  [TTL](ConceptMap-ConceptMapVendorToLOINC.ttl.md) 

## ConceptMap: Vendor Proprietary Codes to LOINC Mapping 

| | |
| :--- | :--- |
| *Official URL*:https://2rdoc.pt/ig/ios-lifestyle-medicine/ConceptMap/ConceptMapVendorToLOINC | *Version*:0.1.0 |
| Active as of 2024-11-21 | *Computable Name*:ConceptMapVendorToLOINC |

 
Operational ConceptMap for translating proprietary wearable device codes to LOINC standard terminology. Based on gray literature analysis of 75 sources documenting 11 major vendors with 0% LOINC adoption rate. 

 
Enables semantic interoperability between vendor-specific wearable device data and EHR systems using LOINC. Critical for multi-vendor data aggregation in Learning Health Systems and lifestyle medicine research. 

Mapeamento de (não especificado) para (não especificado)

**Grupo 1**Mapeamento de `https://developer.apple.com/documentation/healthkit` to [Logical Observation Identifiers, Names and Codes (LOINC)](http://terminology.hl7.org/6.5.0/CodeSystem-v3-loinc.html)

* **Código fonte**: HKQuantityTypeIdentifierHeartRateVariabilitySDNN (Heart Rate Variability SDNN)
  * **Relacionamento**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Código de destino**: 80404-7 (R-R interval.standard deviation (Heart rate variability))
  * **Comentário**: CRITICAL VENDOR ERROR: Apple mislabels this metric. Despite the identifier name containing 'SDNN', Apple Watch actually measures and returns RMSSD (Root Mean Square of Successive Differences), NOT SDNN. This is a well-documented naming error in Apple's HealthKit API. Implementers must map to LOINC 80404-7 but understand the actual metric is RMSSD. See: Hernando et al. 2018, Sensors 18(8):2619.
* **Código fonte**: HKQuantityTypeIdentifierHeartRate (Heart Rate)
  * **Relacionamento**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Código de destino**: 8867-4 (Heart rate)
  * **Comentário**: 
* **Código fonte**: HKQuantityTypeIdentifierRestingHeartRate (Resting Heart Rate)
  * **Relacionamento**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Código de destino**: 40443-4 (Heart rate --resting)
  * **Comentário**: 
* **Código fonte**: HKQuantityTypeIdentifierStepCount (Step Count)
  * **Relacionamento**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Código de destino**: 55423-8 (Number of steps in 24 hour Measured)
  * **Comentário**: 
* **Código fonte**: HKQuantityTypeIdentifierDistanceWalkingRunning (Walking + Running Distance)
  * **Relacionamento**: [maps to wider concept](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#wider)
  * **Código de destino**: 41950-7 (Number of steps)
  * **Comentário**: Distance is wider concept than step count; approximate mapping
* **Código fonte**: HKQuantityTypeIdentifierOxygenSaturation (Oxygen Saturation)
  * **Relacionamento**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Código de destino**: 2708-6 (Oxygen saturation in Arterial blood)
  * **Comentário**: 
* **Código fonte**: HKQuantityTypeIdentifierRespiratoryRate (Respiratory Rate)
  * **Relacionamento**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Código de destino**: 9279-1 (Respiratory rate)
  * **Comentário**: 
* **Código fonte**: HKQuantityTypeIdentifierBodyMass (Body Mass)
  * **Relacionamento**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Código de destino**: 29463-7 (Body weight)
  * **Comentário**: 
* **Código fonte**: HKQuantityTypeIdentifierHeight (Height)
  * **Relacionamento**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Código de destino**: 8302-2 (Body height)
  * **Comentário**: 
* **Código fonte**: HKQuantityTypeIdentifierBodyMassIndex (Body Mass Index)
  * **Relacionamento**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Código de destino**: 39156-5 (Body mass index (BMI) [Ratio])
  * **Comentário**: 

-------

**Grupo 2**Mapeamento de `https://dev.fitbit.com/build/reference/web-api` to [Logical Observation Identifiers, Names and Codes (LOINC)](http://terminology.hl7.org/6.5.0/CodeSystem-v3-loinc.html)

* **Código fonte**: activities-heart-hrv-dailyRmssd (Daily RMSSD)
  * **Relacionamento**: (not mapped)
  * **Código de destino**: Fitbit correctly labels RMSSD (unlike Apple). However, NO LOINC code exists for RMSSD as of November 2024. Maps conceptually to parasympathetic activity. Fitbit API: GET /1/user/-/hrv/date/{date}.json
* **Código fonte**: activities-steps (Daily Steps)
  * **Relacionamento**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Código de destino**: 55423-8 (Number of steps in 24 hour Measured)
  * **Comentário**: 
* **Código fonte**: activities-heart-restingHeartRate (Resting Heart Rate)
  * **Relacionamento**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Código de destino**: 40443-4 (Heart rate --resting)
  * **Comentário**: 
* **Código fonte**: sleep-efficiency
  * **Relacionamento**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Código de destino**: 93832-4 (Sleep efficiency)
  * **Comentário**: 

-------

**Grupo 3**Mapeamento de `https://developer.garmin.com/health-api` to [Logical Observation Identifiers, Names and Codes (LOINC)](http://terminology.hl7.org/6.5.0/CodeSystem-v3-loinc.html)

* **Código fonte**: dailySteps
  * **Relacionamento**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Código de destino**: 55423-8 (Number of steps in 24 hour Measured)
* **Código fonte**: restingHeartRate
  * **Relacionamento**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Código de destino**: 40443-4 (Heart rate --resting)
* **Código fonte**: maxHeartRate (Maximum Heart Rate)
  * **Relacionamento**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Código de destino**: 8889-8 (Heart rate 24 hour maximum)
* **Código fonte**: avgSpo2 (Average SpO2)
  * **Relacionamento**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Código de destino**: 2708-6 (Oxygen saturation in Arterial blood)

-------

**Grupo 4**Mapeamento de `https://www.polaraccesslink.com/v3` to [Logical Observation Identifiers, Names and Codes (LOINC)](http://terminology.hl7.org/6.5.0/CodeSystem-v3-loinc.html)

* **Código fonte**: heart-rate
  * **Relacionamento**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Código de destino**: 8867-4 (Heart rate)
  * **Comentário**: Polar H10 chest strap provides ECG-quality heart rate. Gold standard for wearable HRV measurement.
* **Código fonte**: rr-intervals
  * **Relacionamento**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Código de destino**: 8636-3 (R-R interval in EKG)
  * **Comentário**: 

-------

**Grupo 5**Mapeamento de `https://cloud.ouraring.com/v2/usercollection` to [Logical Observation Identifiers, Names and Codes (LOINC)](http://terminology.hl7.org/6.5.0/CodeSystem-v3-loinc.html)

* **Código fonte**: hrv_balance (HRV Balance Score)
  * **Relacionamento**: (not mapped)
  * **Código de destino**: Oura's proprietary HRV score (0-100). NOT raw RMSSD or SDNN. Derived from nocturnal RMSSD but normalized to individual baseline. No direct LOINC equivalent - this is a processed/scored metric, not a physiological measurement.
* **Código fonte**: hr_lowest (Lowest Heart Rate (overnight))
  * **Relacionamento**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Código de destino**: 8891-4 (Heart rate 24 hour minimum)
  * **Comentário**: 
* **Código fonte**: hr_average (Average Heart Rate (overnight))
  * **Relacionamento**: [narrower](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#narrower)
  * **Código de destino**: 8890-6 (Heart rate 24 hour mean)
  * **Comentário**: Oura measures overnight only, not full 24 hours
* **Código fonte**: breathing_rate (Breathing Rate (overnight))
  * **Relacionamento**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Código de destino**: 9279-1 (Respiratory rate)
  * **Comentário**: 

 IG © 2024+ [Ricardo Lourenço dos Santos](https://linktr.ee/ricardolsantos). Package iOS-Lifestyle-Medicine#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-11-27 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

