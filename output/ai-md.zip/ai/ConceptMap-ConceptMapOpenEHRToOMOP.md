# openEHR Archetype to OMOP CDM Mapping - iOS Lifestyle Medicine Implementation Guide v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **openEHR Archetype to OMOP CDM Mapping**

iOS Lifestyle Medicine Implementation Guide - Compilação de desenvolvimento local (v0.1.0) construída pelas ferramentas de compilação FHIR (HL7® FHIR® Standard). Veja o [Diretório de versões publicadas](https://2rdoc.pt/ig/ios-lifestyle-medicine/history.html)

*  [Narrative Content](#) 
*  [XML](ConceptMap-ConceptMapOpenEHRToOMOP.xml.md) 
*  [JSON](ConceptMap-ConceptMapOpenEHRToOMOP.json.md) 
*  [TTL](ConceptMap-ConceptMapOpenEHRToOMOP.ttl.md) 

## ConceptMap: openEHR Archetype to OMOP CDM Mapping 

| | |
| :--- | :--- |
| *Official URL*:https://2rdoc.pt/ig/ios-lifestyle-medicine/ConceptMap/ConceptMapOpenEHRToOMOP | *Version*:0.1.0 |
| Active as of 2025-11-25 | *Computable Name*:ConceptMapOpenEHRToOMOP |

 
Mapping from custom openEHR archetypes for wearable lifestyle medicine data to OMOP CDM v5.4 concepts. 
Target OMOP Tables: 
* MEASUREMENT: HRV metrics, sleep metrics, activity metrics
* DEVICE_EXPOSURE: Wearable device usage periods
* OBSERVATION: Categorical lifestyle data
 
Key OMOP Concepts Used: 
* 3034658: Heart rate variability
* 40771110: Sleep duration
* 4090484: Physical activity
* Custom concepts required for RMSSD, pNN50 (OHDSI Concept ID = 0)
 
Architecture: 
* Compatible with ETL pipelines from EHRbase to OMOP
* Supports ATLAS cohort definitions
* Enables OHDSI network studies
 

 
Enable transformation of wearable health data from openEHR CDRs to OMOP CDM for participation in OHDSI federated research networks. 

Mapeamento de https://ckm.openehr.org/ckm para http://athena.ohdsi.org/search-terms/terms

**Grupo 1**Mapeamento de `openEHR-EHR-OBSERVATION.heart_rate_variability.v0` to `MEASUREMENT`

* **Código fonte**: id5 (SDNN - Standard deviation of NN intervals)
  * **Relacionamento**: [maps to wider concept](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#wider)
  * **Código de destino**: 3034658 (OMOP Concept: Heart rate variability)
  * **Comentário**: OMOP 3034658 maps to general HRV. Store in MEASUREMENT with value_as_number (ms), unit_concept_id = 8587 (millisecond)
* **Código fonte**: id6 (RMSSD - Root mean square of successive differences)
  * **Relacionamento**: (not mapped)
  * **Código de destino**: CRITICAL GAP: RMSSD has NO OMOP concept (Concept ID = 0). Requires local custom concept creation. Most important wearable HRV metric.
* **Código fonte**: id7 (pNN50 - Percentage of NN intervals >50ms)
  * **Relacionamento**: (not mapped)
  * **Código de destino**: GAP: pNN50 has no OMOP concept. Requires local custom concept. Unit: percentage
* **Código fonte**: id13 (LF/HF Ratio)
  * **Relacionamento**: (not mapped)
  * **Código de destino**: GAP: LF/HF ratio has no OMOP concept. Indicates sympathovagal balance. Dimensionless ratio.
* **Código fonte**: id32 (Recording duration)
  * **Relacionamento**: [is related to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#relatedto)
  * **Código de destino**: 4272025 (OMOP Concept: Duration of procedure)
  * **Comentário**: Store as modifier or in MEASUREMENT_TYPE_CONCEPT_ID context. Critical for HRV interpretation (5min vs 24h)
* **Código fonte**: id41 (Physiological state)
  * **Relacionamento**: [is related to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#relatedto)
  * **Código de destino**: 4058895 (OMOP Concept: Body position)
  * **Comentário**: Store in OBSERVATION table with value_as_concept_id for resting/active/sleep states

-------

**Grupo 2**Mapeamento de `openEHR-EHR-OBSERVATION.physical_activity_detailed.v0` to `MEASUREMENT`

* **Código fonte**: id10 (Step count)
  * **Relacionamento**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Código de destino**: 40770386 (OMOP Concept: Number of steps)
  * **Comentário**: Store in MEASUREMENT with value_as_number (count), unit_concept_id = 8554 (count)
* **Código fonte**: id11 (Distance)
  * **Relacionamento**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Código de destino**: 4149130 (OMOP Concept: Distance walked)
  * **Comentário**: Store in MEASUREMENT with value_as_number, unit_concept_id = 8582 (kilometer) or 8504 (meter)
* **Código fonte**: id20 (Active calories)
  * **Relacionamento**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Código de destino**: 4074432 (OMOP Concept: Energy expenditure)
  * **Comentário**: Store in MEASUREMENT with value_as_number, unit_concept_id = 9526 (kilocalorie)
* **Código fonte**: id32 (Moderately active minutes)
  * **Relacionamento**: [maps to wider concept](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#wider)
  * **Código de destino**: 4090484 (OMOP Concept: Physical activity)
  * **Comentário**: Store with qualifier concept for moderate intensity. Unit: minutes. WHO guideline target: 150-300 min/week
* **Código fonte**: id33 (Vigorously active minutes)
  * **Relacionamento**: [maps to wider concept](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#wider)
  * **Código de destino**: 4090484 (OMOP Concept: Physical activity)
  * **Comentário**: Store with qualifier concept for vigorous intensity. Unit: minutes. WHO guideline target: 75-150 min/week

-------

**Grupo 3**Mapeamento de `openEHR-EHR-OBSERVATION.sleep_architecture.v0` to `MEASUREMENT`

* **Código fonte**: id13 (Total sleep time)
  * **Relacionamento**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Código de destino**: 40771110 (OMOP Concept: Sleep duration)
  * **Comentário**: Store in MEASUREMENT with value_as_number, unit_concept_id = 8505 (hour) or 8550 (minute)
* **Código fonte**: id23 (Deep sleep duration)
  * **Relacionamento**: (not mapped)
  * **Código de destino**: GAP: N3/SWS stage duration has no OMOP concept. Critical for sleep quality assessment. Requires local custom concept.
* **Código fonte**: id24 (REM sleep duration)
  * **Relacionamento**: (not mapped)
  * **Código de destino**: GAP: REM stage duration has no OMOP concept. Important for memory consolidation assessment. Requires local custom concept.
* **Código fonte**: id30 (Sleep efficiency)
  * **Relacionamento**: (not mapped)
  * **Código de destino**: GAP: TST/TIB ratio (%) has no OMOP concept. Key metric for sleep quality. Normal: >85%
* **Código fonte**: id40 (Sleep score)
  * **Relacionamento**: (not mapped)
  * **Código de destino**: Proprietary composite score (0-100). Not suitable for cross-vendor research. Store with vendor qualifier.
* **Código fonte**: id53 (Average HRV (RMSSD) during sleep)
  * **Relacionamento**: (not mapped)
  * **Código de destino**: Depends on RMSSD custom concept creation. Critical for recovery assessment.

-------

**Grupo 4**Mapeamento de `openEHR-EHR-CLUSTER.wearable_device.v0` to `DEVICE_EXPOSURE`

* **Código fonte**: id2 (Device platform)
  * **Relacionamento**: [maps to wider concept](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#wider)
  * **Código de destino**: 4044180 (OMOP Concept: Wearable sensor)
  * **Comentário**: Store in DEVICE_EXPOSURE with device_concept_id = 4044180. Add vendor qualifier in device_source_value
* **Código fonte**: id3 (Device model)
  * **Relacionamento**: [is related to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#relatedto)
  * **Código de destino**: 4044180 (Store in device_source_value)
  * **Comentário**: Store specific model name in device_source_value field (e.g., 'Apple Watch Series 9')
* **Código fonte**: id4 (Device category)
  * **Relacionamento**: [is related to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#relatedto)
  * **Código de destino**: 44818707 (OMOP Concept: Patient self-reported)
  * **Comentário**: Use device_type_concept_id = 44818707 for wearable-generated data provenance
* **Código fonte**: id23 (Serial number)
  * **Relacionamento**: [is equivalent to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#equivalent)
  * **Código de destino**: 32882 (Store in unique_device_id)
  * **Comentário**: Map to unique_device_id field in DEVICE_EXPOSURE
* **Código fonte**: id20 (Firmware version)
  * **Relacionamento**: [is not related to](http://hl7.org/fhir/R5/codesystem-concept-map-relationship.html#disjoint)
  * **Código de destino**: 0 (Not mapped - metadata only)
  * **Comentário**: Firmware version not typically stored in OMOP CDM. Consider NOTE table or custom extension.

 IG © 2024+ [Ricardo Lourenço dos Santos](https://linktr.ee/ricardolsantos). Package iOS-Lifestyle-Medicine#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-11-27 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

