#  - iOS Lifestyle Medicine Implementation Guide v0.1.0

iOS Lifestyle Medicine Implementation Guide - Compilação de desenvolvimento local (v0.1.0) construída pelas ferramentas de compilação FHIR (HL7® FHIR® Standard). Veja o [Diretório de versões publicadas](https://2rdoc.pt/ig/ios-lifestyle-medicine/history.html)

*  [Narrative Content](CodeSystem-nutrition-data-source-cs.md) 
*  [XML](CodeSystem-nutrition-data-source-cs.xml.md) 
*  [JSON](CodeSystem-nutrition-data-source-cs.json.md) 
*  [TTL](CodeSystem-nutrition-data-source-cs.ttl.md) 

## : NutritionDataSourceCS - Change History

History of changes for nutrition-data-source-cs .

 IG © 2024+ [Ricardo Lourenço dos Santos](https://linktr.ee/ricardolsantos). Package iOS-Lifestyle-Medicine#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-03 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

