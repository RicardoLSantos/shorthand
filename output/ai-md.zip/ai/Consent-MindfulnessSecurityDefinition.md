# MindfulnessSecurityDefinition - iOS Lifestyle Medicine Implementation Guide v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **MindfulnessSecurityDefinition**

iOS Lifestyle Medicine Implementation Guide - Compilação de desenvolvimento local (v0.1.0) construída pelas ferramentas de compilação FHIR (HL7® FHIR® Standard). Veja o [Diretório de versões publicadas](https://2rdoc.pt/ig/ios-lifestyle-medicine/history.html)

*  [Narrative Content](#) 
*  [XML](Consent-MindfulnessSecurityDefinition.xml.md) 
*  [JSON](Consent-MindfulnessSecurityDefinition.json.md) 
*  [TTL](Consent-MindfulnessSecurityDefinition.ttl.md) 

## Example Consent: MindfulnessSecurityDefinition

**status**: Active

**scope**: Privacy Consent

**category**: Consent Document

**patient**: [Test Mindfulness Other, DoB: 1980-01-01 ( http://example.org/patients#mindfulness-patient)](Patient-PatientMindfulness.md)

**dateTime**: 2024-01-01

**organization**: [Organization 2RDoc Healthcare Solutions](Organization-Org2RDoc.md)

### Policies

| | | |
| :--- | :--- | :--- |
| - | **Authority** | **Uri** |
| * | [http://terminology.hl7.org/CodeSystem/consentpolicycodes](http://terminology.hl7.org/6.5.0/CodeSystem-consentpolicycodes.html) | [http://terminology.hl7.org/CodeSystem/consentpolicycodes](http://terminology.hl7.org/6.5.0/CodeSystem-consentpolicycodes.html) |

> **provision****type**: Opt In**period**: 2024-01-01 --> 2025-12-31

### Actors

| | | |
| :--- | :--- | :--- |
| - | **Role** | **Reference** |
| * | data collector | Identifier: 1234567890 |

**securityLabel**:[Confidentiality N](http://terminology.hl7.org/6.5.0/CodeSystem-v3-Confidentiality.html#v3-Confidentiality-N): normal**purpose**:[ActReason TREAT](http://terminology.hl7.org/6.5.0/CodeSystem-v3-ActReason.html#v3-ActReason-TREAT): treatment**dataPeriod**: 2024-01-01 --> 2025-12-31

 IG © 2024+ [Ricardo Lourenço dos Santos](https://linktr.ee/ricardolsantos). Package iOS-Lifestyle-Medicine#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-02 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

